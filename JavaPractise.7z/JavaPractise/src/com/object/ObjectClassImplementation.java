package com.object;

public class ObjectClassImplementation extends Object{

	public static void main(String[] args) {

		Object o = new Object();
		Object o1 = new Object();
		Class<? extends Object> class1 = o.getClass();
		String string = o.toString();
		boolean equals = o.equals(o1);
		System.out.println(string);
	}

}
