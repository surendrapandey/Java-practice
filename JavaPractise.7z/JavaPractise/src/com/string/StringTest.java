package com.string;

public class StringTest {

	public static void main(String[] args) {

		String s = "a";
		if(s.equals(null)) {
			System.out.println("null in as argument");
		}
	}

}
