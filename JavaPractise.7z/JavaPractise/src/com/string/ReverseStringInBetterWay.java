package com.string;

public class ReverseStringInBetterWay {

	public static void main(String[] args) {

		String s = "this";
		char [] arr = s.toCharArray();
		char temp;
		for (int i = 0,  j = arr.length-1;  i<j; i++, j--) {
			temp = arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
