package com.string;

import java.util.Stack;

public class ReverseStringUsingStack {

	public static void main(String[] args) {

		//Do not use this apprroch to reverse string
		String s ="this";
		char [] arr = s.toCharArray();
		char [] arr1 = new char[arr.length];
		Stack<Character> stack = new Stack<>();
		for (int i = 0; i < arr.length; i++) {
			stack.push(arr[i]);
		}
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(stack.pop());
		}
		
		
		
	}

}
