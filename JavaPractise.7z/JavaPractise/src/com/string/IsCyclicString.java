package com.string;

import java.util.Arrays;

public class IsCyclicString {

	public static void main(String[] args) {

		//Two strings are cyclic if they have character in sequence.
		boolean isCyclicString = isCyclicString("string","ringsst");
		System.out.println(isCyclicString);
	}

	private static boolean isCyclicString(String s1, String s2) {
		if(s1.length() != s2.length()) {
			return false;
		}
		char [] cs1 = s1.toCharArray();
		char [] cs2 = s2.toCharArray();
		
		Arrays.sort(cs1);
		s1 = new String(cs1);
		
		Arrays.sort(cs2);
		s2 = new String(cs2);
		return s1.equals(s2);
	}

}
