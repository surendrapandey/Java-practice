package com.string;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class StringStringBuilderBufferExample {

	public static void main(String[] args) {

		//StringBuffer //Four constructor.
//		StringBuffer sbf = new StringBuffer(); //take 
		StringBuffer sbf = new StringBuffer(); //What is Default capacity; Default char[] array size;
		System.out.println(sbf.capacity()); //sbf.ensureCapacity(50); System.out.println(sbf.capacity());
		sbf.append("abcd");	//sbf.append(new char[] {'e','f'}); sbf.append(1);sbf.append(true); sbf.append(3l); jsbf.append(3f);sbf.append(3F);
//		sbf.setLength(2);
//		System.out.println(sbf.capacity()); //What will be the capacity
//		sbf.delete(1, 2); //sbf.deleteCharAt(2); //What will be the output
		sbf.insert(1, 'b');
		
/*		CharSequence cs = "hi";
		String ss = "hi";
		System.out.println(cs==ss); */
		sbf.trimToSize();
		sbf.getClass();
//		System.out.println(sbf); //What will be the output
		
		
		
///immutability.		
		//To declare a new String object
		String str1 = "Hello";

		//To declare another String object
		String str2 = "Java";

		//When we concatenate two string objects then it will create a new object in memory.
		str2 = str2 + str1;
		
		//To declare a StringBuffer object
		StringBuffer sb = new StringBuffer("Hello");
		sb.append(" Java");
		
		
//Replace all character of the string.		
		String as = "thisisjaisisivisisisisisisisissa";
		String rp = "is";
		System.out.println(as.replace(rp, "--"));
		System.out.println(as.replaceAll("/is/", "++"));
		
//Count how many times we have to replace.
		String[] split = as.split("is");
		System.out.println(split.length-1);
		
//convert String to charArray and vice-versa.
		char[] chars = as.toCharArray();		//To convert full string as array
		System.out.println(chars.length);
		System.out.println(chars);				//This will print string
		
		//char at specific index
		char c = as.charAt(2);					//Get one char at specified index.
		System.out.println(c);
		
		//Copy string characters to char array
		char[] chars1 = new char[7];
		as.getChars(0, 7, chars1, 0);			//Convert part of string into array.
		System.out.println(chars1);
		
//convert String to byteArray.
		byte[] bytes = as.getBytes();			//String to byte array
		System.out.println(new String(bytes));	//byte array to string
		
//what is the use of intern() method.
		String sssss = "this";					//This will not call intern() method.
		String sss = new String("this");		//
		
		
		
//Why Char array is preferred over String for storing password?
		
		
		
		String s11 = "abcde";
		System.out.println(s11.substring(2, 5));
		System.out.println(s11.subSequence(2, 5));
		
		
	}

}
