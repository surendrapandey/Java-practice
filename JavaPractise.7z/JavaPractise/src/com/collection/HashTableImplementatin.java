package com.collection;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class HashTableImplementatin {

	public static void main(String[] args) {

		Map<Integer, String> ht = new Hashtable<>();
		List<String> vector = new Vector<>();
	}

}
