package com.collection;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {

		Map<Integer,String> map  = new HashMap<>();
	}

}
