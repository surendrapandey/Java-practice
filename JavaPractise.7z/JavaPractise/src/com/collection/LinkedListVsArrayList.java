package com.collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedListVsArrayList {

	public static void main(String[] args) {

		List<Integer> l = new LinkedList<>();
		l.add(3);
		l.add(4);
		l.add(5);
		l.add(6);
		l.add(7);
		l.add(8);
		l.add(1, 33);
		System.out.println(l);
		
		List<Integer> al = new ArrayList<>();
		al.add(3);
		al.add(4);
		al.add(5);
		al.add(6);
		al.add(7);
		al.add(8);
		al.add(1, 33);
		System.out.println(al);
	}

}
