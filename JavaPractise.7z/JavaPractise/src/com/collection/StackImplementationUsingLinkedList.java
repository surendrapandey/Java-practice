package com.collection;

import java.util.EmptyStackException;

public class StackImplementationUsingLinkedList {

	public static void main(String[] args) {

		StackImp si = new StackImp(4);
		si.push(2);
		si.push(8);
		System.out.println("no of element -"+ si.size());
		System.out.println(si.pop());
		si.push(9);
		System.out.println(si.pop());
		si.push(8);
		si.push(80);
		si.push(82);
		si.push(81);
		
	}

}


class StackImp{
	
	private int [] arr;
	private int index  = 0;;
	StackImp(int size){
		arr = new int[size];
	}
	
	
	public boolean push(int element) {
		if(isFull()) {
			throw new StackOverflowError();
		}
		arr[index++] = element;
		return true;
	}
	
	public int pop() {
		if(isEmpty()) {
			throw new EmptyStackException();
		}
		return arr[--index];
	}
	
	public boolean isFull() {
		if(index== arr.length-1) {
			return true;
		}
		return false;
	}
	
	public boolean isEmpty() {
		if(index==0) {
			return true;
		}
		return false;
	}
	
	public int size() {
		return index;
	}
	
}
