package com.collection;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapImpl {

	public static void main(String[] args) throws InterruptedException {

		Map<String, Integer> map = new ConcurrentHashMap<>();
		map.put("a", 1);
		map.put("b", 1);
		map.put("c", 2);
		map.put("d", 3);
		
		Set<Map.Entry<String, Integer>> set = map.entrySet();
		int i = 0;
		for(Map.Entry<String, Integer> entry: set) {
			System.out.println(entry.getKey()+"-"+entry.getKey());
			Thread.sleep(1000);
			map.put("g"+i++, 8);
		}
	}

}


class TestMore implements Runnable{
	Map<String, Integer> map ;
	
	
	public TestMore(Map<String, Integer> map) {
		super();
		this.map = map;
	}

	@Override
	public void run () {
		if(map != null) {
			Set<Map.Entry<String, Integer>> set = map.entrySet();
			for(Map.Entry<String, Integer> entry: set) {
				System.out.println(entry.getKey()+"-"+entry.getKey());
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
