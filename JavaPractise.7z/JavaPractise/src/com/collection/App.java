package com.collection;

import java.util.LinkedList;
import java.util.List;

public class App {

	public static void main(String[] args) {

		List<Integer> list = new LinkedList<Integer>();
		
		
		list.add(1);
		list.add(1);
		list.add(1);
		System.out.println(list);
	}

}
