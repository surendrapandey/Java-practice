package com.collection;

public class LinkedListImplementation {

	public static void main(String[] args) {
		LinkedListI l = new LinkedListI();
		l.add(5);
		l.add(7);
		l.add(9);
		l.show();
	}
	
	
}


class LinkedListI {
	Node head;
	
	public void add(int a) {
		Node n = new Node();
		n.data = a;
		n.next = null;
		if(head == null) {
			head = n;
		}else {
			Node n1 = head;
			while(n1.next !=null) {
				n1 = n1.next;
			}
			n1.next = n;
		}
	}
	
	public void show() {
		Node n2 = head;
		
		while(n2.next !=null) {
			System.out.println(n2.data);
			n2 = n2.next;
		}
		System.out.println(n2.data);
	}
}

class Node{
	int data;
	Node next;
}