package com.collection;

import java.util.ArrayList;
import java.util.List;

public class BlockingQueueImplementationUsingLinkList {

	public static void main(String[] args) {

	}

}


class BlockingQueue{
	
	private List<String> queue = new ArrayList<>();
	private int size = 10;
	
	
	public BlockingQueue(int size){
		this.size = size;
	}
	
	public synchronized void enque(String s ) throws InterruptedException {
		while(this.queue.size() == this.size) {
			wait();
		}
		
		if(this.queue.size() == 0) {
			notifyAll();
		}
		queue.add(s);
	}
	
	
	
}
