package com.collection.arraylist;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class ListSetMapComparison {

	public static void main(String[] args) {
		List<String> al = new ArrayList<>();
		List<String> ll = new LinkedList<>();
		
		
		long start = System.currentTimeMillis();
		
		
		//add operation
		for(int i = 0; i < 100000 ; i++) {
			al.add("0"+i);
		}
		System.out.println("al"+(System.currentTimeMillis()- start));
		Iterator<String> itr = al.iterator();
		long start1 = System.currentTimeMillis();
		//get operation
		while(itr.hasNext()) {
			itr.next();
		}
		System.out.println("al - get"+((System.currentTimeMillis()- start1)));
		long start2 = System.currentTimeMillis();
		//remove operation
		for(int i = 0; i<500;i++) {
			al.remove(i);
		}
		System.out.println("al-remove"+(System.currentTimeMillis()- start2));
		
		
		
		
		
		
		long start3 = System.currentTimeMillis();
		for(int i = 0; i < 100000 ; i++) {
			ll.add("0"+i);
		}
		System.out.println("ll"+(System.currentTimeMillis()- start3));
		itr = ll.iterator();
		long start4 = System.currentTimeMillis();
		//get operation
		while(itr.hasNext()) {
			itr.next();
		}
		System.out.println("ll - get"+((System.currentTimeMillis()- start4)));
		
		long start5 = System.currentTimeMillis();
		//remove operation
		for(int i = 0; i<500;i++) {
			ll.remove(i);
		}
		System.out.println("ll-remove"+(System.currentTimeMillis()- start5));
		
		
		
		
		Set<String> s = new HashSet<>();
		Set<String> ss = new LinkedHashSet<>(); 
		Set<String> sss = new TreeSet<>();
		
		long start6 = System.currentTimeMillis();
		for(int i = 0; i < 100000 ; i++) {
			s.add("0"+i);
		}
		System.out.println("hs"+(System.currentTimeMillis()- start6));
		
		itr = s.iterator();
		long start7 = System.currentTimeMillis();
		//get operation
		while(itr.hasNext()) {
			itr.next();
		}
		System.out.println("hs - get"+((System.currentTimeMillis()- start7)));
		
		long start8 = System.currentTimeMillis();
		//remove operation
		for(int i = 0; i<500;i++) {
			s.remove("0"+i);
		}
		System.out.println("hs-remove"+(System.currentTimeMillis()- start8));
		
		
		long start9 = System.currentTimeMillis();
		for(int i = 0; i < 100000 ; i++) {
			ss.add("0"+i);
		}
		System.out.println("lhs"+(System.currentTimeMillis()- start9));
		itr = ss.iterator();
		long start10 = System.currentTimeMillis();
		//get operation
		while(itr.hasNext()) {
			itr.next();
		}
		System.out.println("lhs - get"+((System.currentTimeMillis()- start10)));
		
		long start11 = System.currentTimeMillis();
		//remove operation
		for(int i = 0; i<500;i++) {
			ss.remove("0"+i);
		}
		System.out.println("lhs-remove"+(System.currentTimeMillis()- start11));
		
		
		
		
		
		long start13 = System.currentTimeMillis();
		for(int i = 0; i < 100000 ; i++) {
			sss.add("0"+i);
		}
		System.out.println("ts"+(System.currentTimeMillis()- start13));
		itr = sss.iterator();
		long start14 = System.currentTimeMillis();
		//get operation
		while(itr.hasNext()) {
			itr.next();
		}
		System.out.println("ts - get"+((System.currentTimeMillis()- start14)));
		
		long start15 = System.currentTimeMillis();
		//remove operation
		for(int i = 0; i<500;i++) {
			sss.remove("0"+i);
		}
		System.out.println("ts-remove"+(System.currentTimeMillis()- start15));
		
		
	}

}

//If only add and retrieve action require select arraylist 
//If performing delete operation also then go with Linked List.
