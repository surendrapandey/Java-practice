package com.collection.arraylist;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;



public class ConvertIntegerListToIntArray {
	
	public static void main(String[] args) {
		
		Set<Object> set = new HashSet<>();
		set.add(5.6);
		set.add(1.6);
		set.add(6.6);
		set.add(3.6);
		
		System.out.println(set);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//can store null in treeset;
	/*public static void main(String ... args ) {
		
		Set <String> set = new TreeSet<>();
		set.add(null);
	}*/
}
	
