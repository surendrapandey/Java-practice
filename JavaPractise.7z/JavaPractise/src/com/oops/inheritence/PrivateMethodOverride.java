package com.oops.inheritence;

public class PrivateMethodOverride {

	public static void main(String[] args) {

		A a = new B();
		B b = new B();
		System.out.println(a.i);
	}

}

class A{
	int i = 9;
	private int m() {
		return 0;
		
	}
}

class B extends A{
	int i = 8;
	public int m() {
		return 1;
	}
}
