package com.oops.inheritence;

public class ChildClass extends ParentClass{

	public static void main(String[] args) {
	}
}
