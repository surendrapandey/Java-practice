package com.oops.inheritence;
public class ChildVariable extends ParentVariable {
 
    String instanceVariable = "child variable";
 
    public void printInstanceVariable() {
        System.out.println(instanceVariable);
    }
}