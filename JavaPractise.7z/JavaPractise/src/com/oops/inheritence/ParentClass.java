package com.oops.inheritence;

public class ParentClass {

	
}
