package com.oops.inheritence;
public class ParentVariable {
 
    String instanceVariable = "parent variable";
 
    public void printInstanceVariable() {
        System.out.println(instanceVariable);
    }
}