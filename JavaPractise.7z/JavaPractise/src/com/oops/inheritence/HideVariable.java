package com.oops.inheritence;
public class HideVariable {
 
    private String message = "this is instance variable";
 
    HideVariable() {
        String message = "constructor local variable";
        System.out.println(message);
    }
 
    public void printLocalVariable() {
        String message = "method local variable";
        System.out.println(message);
    }
 
    public void printInstanceVariable() {
        String message = "method local variable";
        System.out.println(this.message);
    }
    
    public static void main(String[] args) {
    	//hide variable
    	/*HideVariable variable = new HideVariable();
    	variable.printLocalVariable();
    	 
    	variable.printInstanceVariable();*/
    	
    	
    	ParentVariable parentVariable = new ParentVariable();
    	ParentVariable childVariable = new ChildVariable();
    	 
    	parentVariable.printInstanceVariable();
    	childVariable.printInstanceVariable();
	}
}