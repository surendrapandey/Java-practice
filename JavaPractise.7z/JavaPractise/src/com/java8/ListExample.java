package com.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListExample {

	public static List<String>  memberNames = Arrays.asList("Amitabh","Shekhar","Aman","Rahul","Shahrukh","Salman","Yana","Lokesh");
}
