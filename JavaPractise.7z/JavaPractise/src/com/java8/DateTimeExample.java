package com.java8;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateTimeExample {

	public static void main(String[] args) {

		String d1 = "2014-03-25"; //yyyy-MM-dd
		
		//Convert date from string to date and get day/month/year from it.
		
		String date = "Jul--03--1988";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM--dd--yyyy");
		LocalDate d = LocalDate.parse(date, dtf);
		int year = d.getYear();
		int month = d.getMonth().getValue();
		int day = d.getDayOfMonth();
		DayOfWeek dayOfWeek = d.getDayOfWeek();
		System.out.println(day);
		System.out.println(d.getMonth().getValue());
		
		//DayOfWeek is an enum representing the 7 days of the week - Monday, Tuesday, Wednesday, Thursday, Friday, Saturday and Sunday.
//		System.out.println(year);
		
		
		
		String ddd = "1988--+07-++-03";
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy--+MM-++-dd");
		LocalDate ld = LocalDate.parse(ddd, f);
		System.out.println(ld.getDayOfMonth());
		System.out.println(ld.isLeapYear());
		System.out.println(ld.getYear());
		
	}

}
