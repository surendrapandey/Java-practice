package com.java8.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ReduceTerminalOperationImplementation {

	public static void main(String[] args) {

		List<Integer> list1 = Arrays.asList(1, 2, 3);
		
		List<String> sList = Arrays.asList("ab","bc","cd","da");
		
		///Stream.reduce() with Accumulator
		
		list1.stream()
			.reduce((a, b) -> a+b)
			.ifPresent(System.out::println);;
		
		System.out.println("-------------------------");
		
		System.out.println("-------------------------------");
		
		sList.stream()
			.reduce((s,ss)-> s+"-|-"+ss)
			.ifPresent(System.out::println);

		
		//Stream.reduce() with Identity and Accumulator
		
		Integer arrSum = Stream.of(10,20,22,12,14).reduce(1000, Integer::sum);
        System.out.println(arrSum);
 
        arrSum = Stream.of(10,20,22,12,14).reduce(1000, (x,y)->x+y);
        System.out.println(arrSum);
 
        String result = Stream.of("java", "c", "c#", "python").reduce("Languages:", (x,y)->x+" | "+y);
        System.out.println(result);
	}

}
