package com.java8.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import javax.swing.RowFilter.ComparisonType;

import java.util.stream.Collectors;

public class AllStreamMethodsImplementation {

	public static void main(String[] args) {
		
		/**
		 * Create Stream 
		 *  
		 */
		//Create Stream from array.
		Integer [] array = {3,4,5,7,9,3,7};
		Stream.of(array);
		
		//Create stream using stream.builder(),
		
		Stream.Builder<Integer> stream = Stream.builder();
		stream.accept(4);
		stream.accept(5);
		stream.accept(7);
		Stream<Integer> empStream = stream.build();
		
		
		/**
		 * Operation on stream.
		 * 
		 */
		//list 1 ..........
		Employee e1 = new Employee("a",10);
		Employee e2 = new Employee("b",20);
		Employee e3 = new Employee("c",30);
		
		List<Employee> list = new ArrayList<>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		
		
		//list 2........
		Employee[] arrayOfEmps = {
		        new Employee(1, "Jeff Bezos", 100000.0), 
		        new Employee(2, "Bill Gates", 200000.0), 
		        new Employee(3, "Mark Zuckerberg", 300000.0),
		        new Employee(4, "BB", 400000.0), 
		        new Employee(50, "Bites", 500000.0), 
		        new Employee(6, "Maberg", 600000.0),
		        new Employee(7, "FBezos", 700000.0), 
		        new Employee(8, "LlGates", 800000.0), 
		        new Employee(9, "Ckerberg", 900000.0)
		    };

		List<Employee> empList = Arrays.asList(arrayOfEmps);
		
		//forEach() . It is a terminal operation after this call it considered that stream has consumed so can not use same stream again
		list.stream().forEach(i -> i.salaryIncrement(2));
//		list.stream().forEach(i -> System.out.println("-----Foreach example ----"+i.getId()+" -"+i.getName()));
		

		//map() - Return a new stream after applying function to each element of original stream.
		Map<Integer, String> map = new HashMap<>();
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		Integer[] empIds = { 1, 2, 3 };
		List<String> collect = Stream.of(empIds).map(i -> map.get(i)).collect(Collectors.toList());
//		System.out.println("-----Map example ----"+collect);
		
		//collect(); This is a terminal function, applied when all processing done on stream and want to get all stuff.
		
		List<Integer> collect2 = map.entrySet().stream().map(i -> i.getKey()).collect(Collectors.toList());
//		collect2.stream().forEach(i -> System.out.println(i));
		
		//filter() //This produce a new stream that contain element from original stream that passes a given test.
		
		List<Employee> collect1 = Stream.of(empIds).map(i -> findById(i)).filter(e -> e!= null).filter(e ->e.getId()>=2).collect(Collectors.toList());
//		Stream.of(empIds).map(i -> findById(i)).filter(e -> e!= null).filter(e ->e.getId()>=2).forEach(e -> System.out.println("filter testing...."+e.getId()+" - "+e.getName()));
		
		//findFirst is a terminal function and return an optional for the first entry in the stream
		
		Employee employee = Stream.of(empIds)
				.map(i -> findById(i))
				.filter(e -> e!=  null)
				.filter(e ->e.getId() >=1)
				.findFirst()
				.orElse(null);
//		System.out.println("findFirst - "+employee.getId());
		
		//toArray get an array out of stream.
		
	//	Employee[] arr = (Employee[]) list.stream().toArray();
		
		//peek() it is a intermediate function Collectors
		
		
		 List<Employee> collect3 = empList.stream()
	      .peek(e -> e.salaryIncrement(10))
	      /*.peek(System.out::println)*/
	      .collect(Collectors.toList());
		 
		 //count It is a terminal function.
		 long count = empList.stream().filter(e -> e.getId()>2).count();
	//	 System.out.println(" count() is -- "+count);
	//	 collect.forEach(System.out::println);
		 System.out.println("******************************SKIP-LIMIT-FILTER******************************************************");
		 
		 //skip() and limit() are intermidiate function
		 empList.stream().filter(e-> e.getId()> 5).skip(1).limit(2).forEach(System.out::println);
		 System.out.println("******************************SORTED******************************************************");

		 //sorted //this sort stream based on comparator(compare()) we pass.
		 List<Employee> collect4 = empList.stream().sorted((i1, i2) -> i1.getName().compareTo(i2.getName())).collect(Collectors.toList());
		 collect4.stream().limit(2).forEach(System.out::println);
		 System.out.println("******************************MIN******************************************************");
		 System.out.println(empList.stream().min(Comparator.comparing(Employee::getId)).get().getName());
		 System.out.println("******************************MAX******************************************************");
		 System.out.println(empList.stream().max(Comparator.comparing(Employee::getId)).get().getName());
		 
		 //Distinct do not take any argument and return distinct element distinct element in the stream.
		 //it uses equals method of element to decide whether two element or equal or not.
		 System.out.println("******************************DISNICT******************************************************");
		 Stream.of(array).distinct().forEach(e ->System.out.println(e.toString()));
		 List<Integer> collect5 = Arrays.asList(array).stream().distinct().collect(Collectors.toList());
		 collect5.forEach(System.out::println);
		 
		 //allMatch, anyMatch, noneMatch...
		 
		 List<Integer> intList = Arrays.asList(2, 4, 5, 6, 8);
		 boolean allMatch = intList.stream().allMatch(i -> i%2==0);
		 boolean anyMatch = intList.stream().anyMatch(i -> i%2==0);
		 boolean noneMatch = intList.stream().noneMatch(i -> i%3==0);
		 System.out.println("all match "+allMatch+"..anyMatch - "+ anyMatch+"..noneMatch-"+noneMatch);
	}
	
	static Employee findById(int id) {
		
		if(id == 1) 
			return  new Employee("a",1);
		else if(id == 2)
			return  new Employee("b",2);
		else
			return  new Employee("c",3);
		
	}

}







//////--------------------------------------
class Employee{
	private String name ;
	private Integer id;
	private double salary;
	
	
	
	
	public Employee(Integer id, String name, double salary) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
	}

	Employee(String name, Integer id){
		super();
		this.name = name;
		this.id= id;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public void salaryIncrement(int i) {
		this.salary = this.salary+(salary/i);
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id +", salary = "+salary+ "]";
	}
	
	
	
	
}
