package com.java8.stream;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

import org.omg.Messaging.SyncScopeHelper;

public class MinTerminalImplementation {

	public static void main(String[] args) {

		/*Stream.of(3,4,7,8,5,2).min(Comparator.comparing(Integer::valueOf)).ifPresent(System.out::println);
		System.out.println("------------");
		Stream.of("thiss","is","not","m"
				+ "","function").min(Comparator.comparing(String::valueOf)).ifPresent(System.out::println);
		
		LocalDate d1 = LocalDate.now();
		LocalDate d2 = d1.plusDays(5);
		LocalDate d3 = d1.minusDays(5); //min
		LocalDate d4 = d1.plusDays(10); //max
		
		System.out.println("----Min date--------");
		Stream.of(d1,d2,d3,d4).max(Comparator.comparing(LocalDate::toEpochDay).reversed()).ifPresent(System.out::println);
		
		System.out.println("-----Max Date-------");
		Stream.of(d1,d2,d3,d4).min(Comparator.comparing(LocalDate::toEpochDay).reversed()).ifPresent(System.out::println);*/
		
		Stud s = new Stud("su",56);
		Stud s1 = new Stud("bi",26);
		Stud s2 = new Stud("aai",36);
		Stud s3 = new Stud("aah",96);
		Stud s4 = new Stud("ti",13);
		Stud s5 = new Stud("ti",14);
		Stud s6 = new Stud("ti",12);
		Stud s7 = new Stud("li",23);
		
		Stream.of(s,s1,s2,s3,s4,s5,s6,s7)
			.min(Comparator
					.comparing(Stud::getName)
					.reversed()
					.thenComparing(Comparator
							.comparing(Stud::getAge)))
			.ifPresent(e->System.out.println(e.getName()+" "+e.getAge()));
		
		
		
	}

}


class Stud{
	private String name;
	private Integer age;
	
	
	public Stud(String name, Integer age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	
	
}
