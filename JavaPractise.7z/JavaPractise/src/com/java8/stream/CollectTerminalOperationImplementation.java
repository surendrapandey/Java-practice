package com.java8.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CollectTerminalOperationImplementation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<String> list = Arrays.asList("aaaa","bbbbbbb","cccccccc","dd","hhhhhh","ggg");
		List<String> collectAsList = list.stream()
			.collect(Collectors.toList());
		
		System.out.println(collectAsList);
		
		System.out.println("--------------SET-------------");
		
		
		Set<String> collectAsSet = list.stream()
			.collect(Collectors.toSet());
		
		System.out.println(collectAsSet);
		
		System.out.println("--------Map-------");
		
		Map<String, Object> collectAsMap = list.stream()
												.collect(
														Collectors.toMap(
																Function.identity(), String::getBytes));
		
		System.out.println(collectAsMap);
		
		System.out.println("-----------LinkedList-----------");
		
		LinkedList<String> collectAsLinkList = list.stream()
			.filter(e-> e.length()>4)
			.collect(Collectors.toCollection(LinkedList::new));
		System.out.println(collectAsLinkList);
		System.out.println("-----------HashMap-----------");
		
		Map<Integer, String> collectAsMap2 = list.stream()
			.collect(Collectors.toMap(String::length, Function.identity()));
		System.out.println(collectAsMap2);
		
		System.out.println("----------MapToList------------");
		
		Map<Integer, String> map = new HashMap<>();
        map.put(10, "apple");
        map.put(20, "orange");
        map.put(30, "banana");
        map.put(40, "watermelon");
        map.put(50, "dragonfruit");
        
        List<Integer> keys = new ArrayList<>() ;
        List<String> values = new ArrayList<>();
        values = map.entrySet().stream().peek(e-> keys.add(e.getKey())).filter(e->!e.getValue().equals("banana")).map(e->e.getValue()).collect(Collectors.toCollection(ArrayList::new));
        
        System.out.println(keys);
        System.out.println("Values"+values);
	}

}
