package com.java8.stream;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Count_CountingImplementation {

	public static void main(String[] args) {

		long count = Stream.of("how","to","do","in","java").count();
		System.out.println(count);
		
		Long counting = Stream.of("how","to","do","in","java").collect(Collectors.counting());
		System.out.println(counting);
	}

}
