package com.java8.stream;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Peek_Implementation {

	//peek is use for debugging purpose. as below.
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("one","two","three","four");
				
				stream
				.filter(e-> e.length()>3)
				.peek(e->System.out.println("Value "+e))
				.map(e->e.toUpperCase())
				.peek(e->System.out.println("Next "+e))
				.forEach(System.out::println);
	}

}
