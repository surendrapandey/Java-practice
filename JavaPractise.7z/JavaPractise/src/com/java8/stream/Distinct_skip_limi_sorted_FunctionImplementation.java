package com.java8.stream;

import java.util.Arrays;
import java.util.List;

public class Distinct_skip_limi_sorted_FunctionImplementation {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(1,3,1,2,3,9,5,7,5,6,6,6,8,9);
		list.stream().distinct().forEach(System.out::print);
		System.out.println();
		list.stream().sorted().forEach(System.out::print);
		System.out.println();
		list.stream().distinct().skip(2).limit(3).sorted().forEach(System.out::print);
	}

}
