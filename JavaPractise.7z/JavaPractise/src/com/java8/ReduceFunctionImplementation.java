package com.java8;

import java.util.Optional;

public class ReduceFunctionImplementation {

	public static void main(String[] args) {
		Optional<String> reduced = ListExample.memberNames.stream().reduce((s1,s2) -> s1 + "#" + s2);

		reduced.ifPresent(System.out::println);

//Output: Amitabh#Shekhar#Aman#Rahul#Shahrukh#Salman#Yana#Lokesh
	}

}
