package com.thread;

import java.util.LinkedList;
import java.util.Random;

public class Processor200 {

	private LinkedList<Integer> list = new LinkedList<Integer>();
	private final int LIMIT= 10;
	private Object lock = new Object();
	
	
	public Processor200() {
	}

	public void produce() {
		int value = 0;
		while(true) {
			synchronized(lock) {
				while(list.size() == LIMIT) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
					}
				}
				list.add(value++);
				lock.notify();
			}
		}
	}
	
	public void consume() {
		Random random = new Random();
		
		while(true) {
			synchronized(lock) {
				while(list.size() == 0) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
					}
				}
				System.out.print("List size is - "+list.size());
				int value = list.removeFirst();
				System.out.println("; Value is - "+value);
				lock.notify();
			}
			try {
				Thread.sleep(random.nextInt(1000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
