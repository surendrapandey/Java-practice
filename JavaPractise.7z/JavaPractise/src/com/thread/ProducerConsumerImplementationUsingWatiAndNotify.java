package com.thread;

public class ProducerConsumerImplementationUsingWatiAndNotify {

	public static void main(String[] args) {
		

		final Processor200 processor = new Processor200();
		Thread producer = new Thread(new Runnable() {
			public void run() {
				processor.produce();
			}
		});
		
		Thread consumer = new Thread(new Runnable() {
			public void run() {
				processor.consume();
			}
		});
		
		producer.start();
		consumer.start();
		
		try {
			producer.join();
			consumer.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
