package com.thread.test;
class ThreadB implements Runnable{
	
	Object lock ;
	static boolean printA = true;
	public ThreadB(Object lock) {
		this.lock = lock;
	}
	
	@Override
	public void run() {
		synchronized (lock) {
			if(!printA) {
				System.out.println("B");
				printA = true;
			}
		}
		
	}
}