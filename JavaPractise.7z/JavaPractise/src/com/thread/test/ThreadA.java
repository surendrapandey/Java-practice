package com.thread.test;


public class ThreadA implements Runnable{
	
	Object lock ;
	static boolean printA = true;
	public ThreadA(Object lock) {
		this.lock = lock;
	}
	
	@Override
	public void run() {
		synchronized (lock) {
			if(printA) {
				System.out.println("A");
				printA = false;
			}
		}
		
	}
}