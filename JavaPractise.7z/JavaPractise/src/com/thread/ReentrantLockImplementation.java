package com.thread;

public class ReentrantLockImplementation {

	public static void main(String[] args) throws InterruptedException {

		Runner1 runner = new Runner1();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				try {
					runner.firstThread();
				} catch (InterruptedException e) {
				}
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				try {
					runner.secondThread();
				} catch (InterruptedException e) {
				}
			}
		});
		
		
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		
		runner.finished();
		
	}

}
