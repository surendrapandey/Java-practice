package com.thread;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class CompletableFutureImplementation {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

	/*	CompletableFuture<String> completableFuture = new CompletableFuture<String>();
		completableFuture.complete("Future's Result");//this method use to manually complete the class.
		completableFuture.complete("Future's Result");//this method use to manually complete the class.
		String result = completableFuture.get();//this call will be blocked until future thread get completed.
		System.out.println(result);*/
		
		
		CompletableFuture<Void> future = CompletableFuture.runAsync(() ->{
				System.out.println("Runnable");
				System.out.println("Waiting...............");
				try {
					TimeUnit.SECONDS.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Completed.");
		});
		Thread.sleep(2000);
		System.out.println(Thread.currentThread().getName()+".....Completd");
	}
}
