package com.thread;

public class PrintOutputInSequencialForMultiThread {

	private static boolean printA = true;
	private static int number = 1;
	static Object lock = new Object();

	public static void main(String[] args) {

		Thread t = new Thread(() -> {
			while (number < 20) {
				synchronized (lock) {
					if (number % 2 == 0) {
						System.out.print("=(A-");
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					lock.notify();
					number++;
				}
			}
		});

		Thread t2 = new Thread(() -> {
			while (number <= 20) {
				synchronized (lock) {
					if (number % 2 == 1) {
						System.out.print("B)");
						try {
							lock.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					lock.notify();
					number++;
				}
			}
		});

		t.start();
		t2.start();
	}
}
