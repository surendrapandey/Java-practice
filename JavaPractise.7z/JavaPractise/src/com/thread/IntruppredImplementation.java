package com.thread;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class IntruppredImplementation {

	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("Starting...");
		
		ExecutorService executor = Executors.newCachedThreadPool();
		Future<Void> future = executor.submit(new Callable<Void>() {

			@Override
			public Void call() throws Exception {

				long startTime = System.currentTimeMillis();
				Random random = new Random();
				for(int i =0 ; i<1E6;i++) {
					if(Thread.currentThread().isInterrupted()) {
						System.out.println("Thread interupped! ");
						break;
					}
					Math.sin(random.nextDouble());
				}
				System.out.println("Time taken to complete in mili seconds - " +(System.currentTimeMillis() - startTime));
			
				return null;
			}
			
		});
		executor.shutdown();
	//	Thread.sleep(1);
	//Mulitple way of intrupped thread;
	//	future.cancel(true);
	//	executor.shutdownNow();
	//	Thread.interrupted();
		executor.awaitTermination(1, TimeUnit.DAYS);
		
		System.out.println("Finished!");
		
	}

}
