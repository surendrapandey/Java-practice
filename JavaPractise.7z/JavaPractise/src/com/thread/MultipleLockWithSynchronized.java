package com.thread;

public class MultipleLockWithSynchronized {

	public static void main(String[] args) {
		new Worker().main();
	}

}
