package com.thread;

public class PrintOutputInSequencialFromMultipleThread {
	public static int number = 1;

	public static void main(String[] args) {
		int count = 30;
		Object lock = new Object();
		T1 t1 = new T1(number,lock,count);
		T2 t2 = new T2(number,lock,count);
		T3 t3 = new T3(number,lock,count);
		T4 t4 = new T4(number,lock,count);
		T5 t5 = new T5(number,lock,count);
		
		Thread tt1 = new Thread(t1);
		Thread tt2 = new Thread(t2);
		Thread tt3 = new Thread(t3);
		Thread tt4 = new Thread(t4);
		Thread tt5 = new Thread(t5);
		tt1.start();
		tt2.start();
		tt3.start();
		tt4.start();
		tt5.start();
	}
	
}


class T1 implements Runnable{
	private int limit = 0;
	private String print;
	private Object lock;
	public T1(int number, Object lock, int count) {
		this.lock  = lock;
		this.limit = count;
	}
	public void run() {
			while(PrintOutputInSequencialFromMultipleThread.number<=limit) {
			synchronized (lock) {
					if(PrintOutputInSequencialFromMultipleThread.number % 2 == 0) {
						System.out.print("T1-");
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					lock.notifyAll();
					PrintOutputInSequencialFromMultipleThread.number++;
				}
			}
	}
}

class T2 implements Runnable{
	
	private int limit = 0;
	private Object lock;
	public T2(int number, Object lock, int count) {
		this.lock  = lock;
		this.limit = count;
	}
	public void run() {
		while(PrintOutputInSequencialFromMultipleThread.number<=limit) {
		synchronized (lock) {
				if(PrintOutputInSequencialFromMultipleThread.number % 2 != 0) {
					System.out.print("-T2");
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock.notifyAll();
				PrintOutputInSequencialFromMultipleThread.number++;
			}
		}
	}
}

class T3 implements Runnable{
	
	private int number = 0;
	private int limit = 0;
	private String print;
	private Object lock;
	public T3(String print, Object lock, int count) {
		this.print = print;
		this.lock  = lock;
		this.limit = count;
	}
	public void run() {
		while(print.equals("T3")) {
		synchronized (lock) {
				if(number++<=limit/5) {
					System.out.print("-T3-");
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				print = "T4";
				lock.notifyAll();
			}
		}
	}
}

class T4 implements Runnable{
	
	private int limit = 0;
	private Object lock;
	public T4(int print, Object lock, int count) {
		this.lock  = lock;
		this.limit = count;
	}
	public void run() {
		while(print.equals("T4")) {
		synchronized (lock) {
				if(number++<=limit/5) {
					System.out.print("T4-");
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				print = "T5";
				lock.notifyAll();
			}
		}
	}
}

class T5 implements Runnable{
	
	private int number = 0;
	private int limit = 0;
	private String print;
	private Object lock;
	public T5(String print, Object lock, int count) {
		this.print = print;
		this.lock  = lock;
		this.limit = count;
	}
	public void run() {
		while(print.equals("T5")) {
		synchronized (lock) {
				if(number<=limit/5) {
					System.out.print("T5");
					number++;
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				print = "T6";
				lock.notifyAll();
			}
		}
	}
}
