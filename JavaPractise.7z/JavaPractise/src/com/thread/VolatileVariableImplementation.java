package com.thread;

import java.util.Scanner;

class Processor1 extends Thread{
	//valatile variable is read always by the thread and thread do not make copy of this variable.
	//Generally use this when variable is not getting changed inside the body of run method.
	private volatile boolean running = true;
	
	public void run() {
		while(running) {
			System.out.println("Hello");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void shutdown() {
		running = false;
	}
	
}

public class VolatileVariableImplementation {

	public static void main(String[] args) {
		Processor1 proc1 = new Processor1();
		proc1.start();
		System.out.println("Press enter to stop");
		Scanner sc = new Scanner(System.in);
		sc.nextLine();
		proc1.shutdown();
	}

}
