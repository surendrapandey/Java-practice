package com.thread;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class CallableWithFutureImplementation {

	public static void main(String[] args) throws InterruptedException {

		ExecutorService executor = Executors.newCachedThreadPool();
		

		/**
		 * How to return void from callable
		 * 1. Use wildcard (?) with future and Void with Callable as generic like -> Future<?> future = executor.submit(new Callable<Void>() 
		 * 2. Change return type of call to Void -> public Void call() throws Exception {
		 * 3. Return null for call  -> return null;
		 */
		
		Future<Integer> future = executor.submit(new Callable<Integer>() {

			@Override
			public Integer call() throws Exception {
				Random random = new Random();
				int duration =  random.nextInt(4000);
				if(duration>2000) {
					throw new IOException("duration is greater than ");
				}
				System.out.println("Starting....");
				Thread.sleep(duration);
				System.out.println("Finished:");
				return duration;
			}
			
		});
		
		executor.shutdown();
		executor.awaitTermination(2, TimeUnit.DAYS);
			try {
				System.out.println("Result is : "+future.get());
			} catch (ExecutionException e) {
				System.out.println(e.getMessage());
				System.out.println(e.getCause());
			}
	}

}
