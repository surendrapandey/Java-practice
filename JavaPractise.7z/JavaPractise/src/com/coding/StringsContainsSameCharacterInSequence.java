package com.coding;

public class StringsContainsSameCharacterInSequence {

	//https://www.geeksforgeeks.org/check-whether-two-strings-contain-same-characters-in-same-order/
	public static void main(String[] args) {
		String s1 = "Geedddddks", s2 = "Geedks"; 
		  
	    if (solve(s1, s2)) 
	        System.out.print("Yes"); 
	    else
	        System.out.print("No"); 
	}
	
	private static boolean solve(String s1, String s2) {
		
		StringBuilder sb = new StringBuilder(s1.charAt(0));
		StringBuilder sb2 = new StringBuilder(s2.charAt(0));
		for(int i = 1 ; i< s1.length(); i++) {
			if(s1.charAt(i) != s1.charAt(i-1)) {
				sb.append(s1.charAt(i));
			}
		}
		System.out.println(sb.toString());
		
		for(int i = 1 ; i<s2.length();i++) {
			if(s2.charAt(i) != s2.charAt(i-1)) {
				sb2.append(s2.charAt(i));
			}
		}
		System.out.println(sb2.toString());
		
		if(sb.length() == sb2.length()) {
			return true;
		}
		return false;
	}

}
