package com.coding;

public class AddCharIntLong {

	public static void main(String[] args) {

		        int i = (byte) + (char) - (int) + (long) - 1;
		 
		        System.out.println((byte)+1);
	}

}
