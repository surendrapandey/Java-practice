package com.coding;
public class CodingExamples
{
    public static void main(String args[])
    {
        System.out.println(1);
 
         https://javaconceptoftheday.com/
 
        System.out.println(2);
    }
}