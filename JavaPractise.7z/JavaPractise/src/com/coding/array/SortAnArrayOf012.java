package com.coding.array;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SortAnArrayOf012 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
		int t = Integer.parseInt(br.readLine());
		while(t-->0) {
			int size = Integer.parseInt(br.readLine());
			int zeros=0;
			int ones=0;
			int twos=0;
			int e = 0;
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			String[] split = line.trim().split("\\s+");
			for(int i =0; i<split.length; i++) {
				e = Integer.parseInt(split[i]);
				if(e==0) {
					zeros++;
				}else if(e==1) {
					ones++;
				}else {
					twos++;
				}
			}
			
			for(int i = 0; i<(zeros+ones+twos) ; i++) {
				if(i<zeros) {
					sb.append(0+" ");
				}else if(i<zeros+ones) {
					sb.append(1+" ");
				}else if(i<zeros+ones+twos) {
					sb.append(2+" ");
				}
			}
			System.out.println(sb.toString());
		}
		
	}

}
