package com.coding.array;

import java.util.Scanner;

public class MissingNumberInArray {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int tc = sc.nextInt();
		int size = 0;
		int actualSum = 0;
		int sumWithMissignNum = 0;
		while(tc-- > 0) {
			size = sc.nextInt();
			actualSum = (size*(size+1))/2;
			for(int i = 0; i<size-1;i++) {
				sumWithMissignNum = sumWithMissignNum+sc.nextInt();
			}
			System.out.println(actualSum-sumWithMissignNum);
			sumWithMissignNum =0;
		}
		
	
	}

}
