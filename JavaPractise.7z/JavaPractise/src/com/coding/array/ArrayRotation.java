package com.coding.array;

//Write a function rotate(ar[], d, n) that rotates arr[] of size n by d elements.
public class ArrayRotation {

	public static void main(String[] args) {

		int [] arr = {1,2,3,4,5,6,7};
					//3,4,5,6,7,1,2
		
		arr = rotate(arr,7,2);
		for (int i : arr) {
			System.out.println(i);
		}
	}

	private static int[] rotate(int[] arr, int size, int d) {
		int[] arrr = new int[size];
		if(size<2) {
			return arr;
		}
		
		for(int i = 0; i<size ; i++) {
			arrr[i]=arr[(i+d)%size];
		}
		return arrr;
	}
}
