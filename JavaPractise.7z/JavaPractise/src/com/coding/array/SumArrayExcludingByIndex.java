package com.coding.array;

public class SumArrayExcludingByIndex {

	public static void main(String[] args) {

		int arr [] = {5,4,3,8,9,1}; //sum is 30
		//			 25,26,27,22,21,29
		arr = sumArrayInOrderN(arr);
		arr = sumArray(arr);
		for (int i= 0; i<arr.length ; i++) {
			System.out.print(arr[i]+",");
		}
	}

	private static int[] sumArrayInOrderN(int[] arr) {
		return null;
	}

	private static int[] sumArray(int[] arr) {
		if(arr.length == 1) {
			return arr;
		}
		int length = arr.length;
		int finalArr [] = new int[length];
		int leftArraySum = 0;
		int rightArraySum = 0;
		for(int i = 0; i< length ; i++) {
			if(i == 0) {
				finalArr [0]=calculateSumForIndex(arr,1,length-1);
			}else if(i == length-1) {
				finalArr[length-1] = calculateSumForIndex(arr, 0, length-2);
			}else {
				leftArraySum = calculateSumForIndex(arr, 0, i-1);
				rightArraySum = calculateSumForIndex(arr, i+1, length-1);
				finalArr[i] = leftArraySum+rightArraySum;
			}
		}
		
		return finalArr;
	}

	private static int calculateSumForIndex(int[] arr, int i, int j) {
		if(arr.length ==1) {
			return arr[0];
		}
		int sum = 0;
		for(;i<=j;i++) {
			sum +=arr[i];
		}
		return sum;
	}

}
