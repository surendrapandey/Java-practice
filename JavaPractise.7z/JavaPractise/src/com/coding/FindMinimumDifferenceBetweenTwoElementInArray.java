package com.coding;

import java.util.Arrays;

public class FindMinimumDifferenceBetweenTwoElementInArray {

	public static void main(String[] args) {

		int [] arr = {12,5,9,2,78};
		int [] arr1 = {0,2,5,8,9};
		int [] arr5 = {9,8,7,6,5,4,3,2,1};
		int [] arr4 = {26,10,21,65,70};
		int [] arr3 = {33,333,3333,33333,3333333};
		int [] arr2 = {56,65,646,654,656};
		System.out.println(getDiff(arr, arr.length));//3
		System.out.println(getDiff(arr1, arr.length)); //1
		System.out.println(getDiff(arr2, arr.length));//2
		System.out.println(getDiff(arr3, arr.length));//300
		System.out.println(getDiff(arr4, arr.length));//5
		System.out.println(getDiff(arr5, arr.length));//1
	}
	
	private static int getDiff(int [] arr, int n) {
		
		Arrays.sort(arr);
		int minDiff = arr[1]-arr[0];
		
		for(int i = 1; i<arr.length-1; i++) {
			if(minDiff > (arr[i+1]-arr[i])) {
				minDiff = arr[i+1]-arr[i];
			}
		}
		return minDiff;
	}

}
