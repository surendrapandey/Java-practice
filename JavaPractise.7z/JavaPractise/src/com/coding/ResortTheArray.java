package com.coding;

import java.util.ArrayList;
import java.util.List;

public class ResortTheArray {

	public static void main(String[] args) {

		int [] arr = {-8,-5,-3,-1,3,6,9};
		
		List<Integer> l = new ArrayList<Integer>();
		for(int i = 0; i<arr.length;i++) {
			if(arr[i]>0) {
				break;
			}else {
				l.add(arr[i]);
			}
		}
		int[] negArray  = reverseList(l);
		arr = mergeArray(negArray,arr);
		
		for(int i = 0; i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
	}

	private static int [] reverseList(List<Integer> l) {
		int[] arr = new int[l.size()];
		for(int i = l.size()-1,j=0; i>=0;i--) {
			arr[j++] =l.get(i);
		}
		return arr;
	}

	private static int[] mergeArray(int[] narr, int[] arr) {
		
		int indexOfNegative = 0;
		int indexOfPositive = narr.length;
		
		int [] arr1 = new int[arr.length];
		
		for(int i = 0;i<arr.length;i++) {
			if(indexOfNegative<narr.length && indexOfPositive<arr.length) {
				if(Math.abs(narr[indexOfNegative])<=arr[indexOfPositive]) {
					arr1[i] = narr[indexOfNegative++];
					
				}else if(Math.abs(narr[indexOfNegative])>arr[indexOfPositive]){
					arr1[i] = arr[indexOfPositive++];
				}
			}else if(indexOfNegative>=narr.length &&indexOfPositive<arr.length) {
				arr1[i] = arr[indexOfPositive++];
			}else if(indexOfPositive>=arr.length && indexOfNegative<narr.length) {
				arr1[i] = narr[indexOfNegative++];
			}
		}
		return arr1;
	}

}
