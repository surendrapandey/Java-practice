package com.coding;

public class SubSequenceExistWithSumEqualToK {

	//https://www.geeksforgeeks.org/check-whether-a-subsequence-exists-whose-sum-is-equal-to-k-if-arri-2arri-1/
	public static void main(String[] args) {
		//Check whether a subsequence exists with sum equal to k if arr[i]> 2*arr[i-1]
		
	//	arr[i]>(arr[i-1]+arr[i-2]);
		
		int A[] = { 1, 3, 7, 15, 31 }; 
	    int n = A.length; 
	    System.out.println(CheckForSequence(A, n, 18) ?  
	                                            "True": "False"); 
		
	}

	private static boolean CheckForSequence(int[] arr, int n, int k) {
		
		for(int i = n-1; i>=0; i--) {
			if(arr[i] <=k) {
				k -=arr[i];
			}
		}
		if(k==0) {
			return true;
		}
		return false;
	}

}
