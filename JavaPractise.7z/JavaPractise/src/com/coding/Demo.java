package com.coding;


class Rom{
	int a;
	int b;
	Rom(int i, int j){
		a=i;
		b=j;
	}
	
	void meth(Rom m ) {
		m.a *=2;
		m.b /=2;
	}
}
public class Demo {

	public static void main(String[] args) {
		Rom obj = new Rom(10,20);
		obj.meth(obj);
		System.out.println(obj.a+" "+obj.b);
		
	}

}
