package com.coding;

public class RotateArray {

	public static void main(String[] args) {
		//int [][] t1 = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
		int [][] t1 = {{1,2,3},{4,5,6},{7,8,9}};
		int [][] t = rotateBy90Clockwise(t1);
		for(int i = 0; i<t.length;i++) {
			for(int j=0; j<t.length; j++) {
				System.out.println(t[i][j]);
			}
		}
	}
	
	static int [][] rotateBy90Clockwise(int [][] input){

		int n =input.length;
		int m = input[0].length;
		int [][] output = new int [m][n];

		for (int i=0; i<n; i++)
			for (int j=0;j<m; j++)
				output [j][n-1-i] = input[i][j];
		return output;
		}
}
