package com.coding;

public class IsStringAnagram {

	public static void main(String[] args) {

		boolean isStringsAnagram = isAnagram("abcdd","abcd");
		System.out.println(isStringsAnagram);
	}

	private static boolean isAnagram(String s, String ss) {
		
		int [] arr = new int[26];
		
		for (char c : s.toCharArray()) {
			arr[c-'a']++;
		}
		
		for (char c : ss.toCharArray()) {
			arr[c-'a']--;
		}
		int result = 0;
		for (int  i : arr) {
			result +=Math.abs(i);
		}
		if(result == 0) {
			return true;
		}
		
		return false;
	}

}
