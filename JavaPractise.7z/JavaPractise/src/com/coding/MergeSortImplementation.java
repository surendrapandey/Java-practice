package com.coding;

public class MergeSortImplementation {

	public static void main(String[] args) {

		int [] a = {6,5,2,8,3,4,9};
		a = mergeSort(a,0,a.length-1);
		
		for (int i : a) {
			System.out.print(i+" ,");
		}
	}

	private static int[] mergeSort(int[] a, int low, int high) {
		if(low == high)
			return a;
		int mid = (low+high)/2;
		int [] left =new int [mid+1];
		for (int i = 0; i < mid+1; i++) {
			left[i] = a[i];
		}
		left = 	mergeSort(left, low, mid);
		
		int [] right = new int[high-mid];
		for (int i = 0; i < right.length; i++) {
			right[i] = a[++mid];
		}
				
		right =	mergeSort(right, low, right.length-1);
		
		return merge(left,right);
	}

	private static int[] merge(int[] left, int[] right) {
		
		int i =0,j=0,k=0;
		int [] a = new int[left.length+right.length];
		
		while(i<left.length && j<right.length) {
			if(left[i] < right[j]) {
				a[k++] = left[i++];
			}else {
				a[k++] = right[j++];
			}
		}
		
		while(i<left.length) {
			a[k++] = left[i++];
		}
		
		while(j<right.length) {
			a[k++] = right[j++];
		}
		return a;
	}

}
