package com.coding;

import java.io.IOException;

public class OpenNotepadUsingJavaCode
{
    public static void main(String[] args)
    {
        try
        {
            Runtime.getRuntime().exec("notepad.exe");
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}