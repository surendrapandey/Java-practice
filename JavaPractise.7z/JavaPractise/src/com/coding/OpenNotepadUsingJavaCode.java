package com.coding;

import java.io.IOException;

public class OpenNotepadUsingJavaCode
{
    public static void main(String[] args)
    {
        try
        {
          //  Runtime.getRuntime().exec("notepad.exe");
        	System.out.println(Runtime.getRuntime().maxMemory());
        	System.out.println(Runtime.getRuntime().freeMemory());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}