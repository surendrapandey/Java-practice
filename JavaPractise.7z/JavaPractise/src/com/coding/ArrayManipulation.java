package com.coding;

public class ArrayManipulation {

	//https://www.hackerrank.com/challenges/crush/problem?h_l=interview&playlist_slugs%5B%5D=interview-preparation-kit&playlist_slugs%5B%5D=arrays
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [][]arr= {{3,4},{3,4,5}};
		System.out.println(arr.length);
	}
	
	private static long arrayManipulation(int n, int[][] queries) {
		
		long mina = 0;
		long maxa = 0;
		long minb = 0;
		long maxb = 0;
		long tempa = 0;
		long tempb = 0;
		long tempk = 0;
		long k = 0;
		
		
		long max = 0;
		for(Integer i = 0; i<queries.length; i++) {
			 tempa= queries[i][0]-1;
			 if(tempa<mina) {
				 mina = tempa;
			 }else if(tempa> maxa) {
				 maxa = tempa;
			 }
			tempb = queries[i][1]-1;
			if(tempb<minb) {
				 minb = tempb;
			 }else if(tempb> maxb) {
				 maxb = tempb;
			 }
			
		}
		
		if(maxa < minb) {
			long[] arr = new long[(int) (minb - maxa+1)];
			for (Integer i = 0; i < queries.length; i++) {
				tempa= maxa - (queries[i][0])-1;
				tempb = (queries[i][1])-1;
				tempk = queries[i][2];
				for (int j = (int) tempa; j <= (tempb); j++) {
					arr[j] += tempk;
					if (max < arr[j]) {
						max = arr[j];
					}
				}
			}
		}else {
			long[] arr = new long[(int) (maxa - minb+1)];
			for (Integer i = 0; i < queries.length; i++) {
				tempa= (queries[i][0])-1;
				tempb = (queries[i][1])-1;
				tempk = queries[i][2];
				for (int j = (int) tempa; j <= (tempb); j++) {
					arr[j] += tempk;
					if (max < arr[j]) {
						max = arr[j];
					}
				}
			}
		}
		
		return max;
	}

}
