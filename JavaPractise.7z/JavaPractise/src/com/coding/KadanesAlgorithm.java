package com.coding;

import java.util.Scanner;

public class KadanesAlgorithm {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int tc = sc.nextInt();
		int size = 0;
		int maxSum = Integer.MIN_VALUE ;
		int sum = 0 ;
		while(tc > 0) {
			tc--;
			size = sc.nextInt();
			int [] arr = new int[size];
			for(int i = 0; i<size;i++) {
				arr[i] = sc.nextInt();
			}
			for(int i = 0; i<size;i++) {
				sum = sum+arr[i];
				
				if(sum > maxSum) {
					maxSum = sum;
				}
				if(sum<0){
					sum = 0;
				}
			}
			System.out.println(maxSum);
			maxSum = Integer.MIN_VALUE;
			sum = 0;
			
		}
		
	}

}
