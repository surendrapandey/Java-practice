package com.assignement;

public class IntegerWithDoubleEquals {

	public static void main(String[] args) {

		//This will work as string
		Integer i = new Integer(3);
		Integer j = new Integer(3);
		Integer iii = 128;
		Integer jjj = 128;
		
		//Integer with range -128 to 127 will go inside integer literal pool.
		Integer ii = 129;
		Integer jj = 129;
		
		String s = new String("");
		
		if(iii==jjj)
			System.out.println("==");
		else if(i.equals(j))
			System.out.println("equals");
		else 
			System.out.println("no");
	}

}
