package com.stream;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StreamListOfObjectToString {

	public static void main(String[] args) {
		Employee e = new Employee(1, "one", "111", 1);
		Employee e1 = new Employee(2, "two", "222", 2);
		Employee e2 = new Employee(3, "two", "333", 3);
		Employee e3 = new Employee(4, "two", "444", 4);
		
		List<Employee> list = new ArrayList<>();
		list.add(e);
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.stream().map(emp -> emp.getFirstName()+"-"+emp.getLastName()).forEach(System.out::println);
	}
	
	
	public void m() {
		
	}

}

class testtesttest{
	public void m1() throws IOException{
		
	}
}

interface testesttesttest {
	
	public void m1() throws IOException;
}

class testtesttesttesttest implements testesttesttest{
	@Override
	public void m1() throws IOException{
		throw new IOException();
	}
}