package com.exception;

public class ReturnFromCatchAndTry {

	public static void main(String[] args) {
		System.out.println(m());
		
	}
	@SuppressWarnings("finally")
	static int m() {
		int i = 0;
		try {
			if( i ==0) {
				throw new NumberFormatException();
			}
			return 1;
		}catch(Exception e) {
			return 2;
		}finally{
			return 3;
		}
	}

}
