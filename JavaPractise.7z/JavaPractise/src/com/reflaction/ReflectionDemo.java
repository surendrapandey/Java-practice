package com.reflaction;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;

public class ReflectionDemo {

	public static void main(String[] args) throws NoSuchFieldException {

		try {
			  String ASTERISK = "*";
			
			String s ="*this*";
			String ss = s.replaceAll("\\"+ASTERISK, "%");
	//		System.out.println(ss);
			Class<?> c = Class.forName("com.reflaction.Person");
			Constructor<?>[] constructors = c.getConstructors();
			/*System.out.println("Constructors - "+Arrays.toString(constructors));
			
			System.out.println("*************************All methods*************************");
			Method[] methods = c.getMethods();
			System.out.println("Methods - "
			+Arrays.toString(methods));
			System.out.println("*************************person class methods*************************");
			Method[] declaredMethods = c.getDeclaredMethods();
			System.out.println("Declared methods - "+Arrays.toString(declaredMethods));
			System.out.println("*************************All declared field*************************");*/
	//		Field[] declaredFields = c.getDeclaredFields();
	//		System.out.println(Arrays.toString(declaredFields));
			try {
				Class<?> forName = Class.forName("com.reflaction.StudentTest");
				System.out.println(forName.getDeclaredField("stud"));
		//		System.out.println(declaredField.toString());
			} catch (SecurityException e) {
				e.printStackTrace();
			}
		//	System.out.println("Declared fields"+Arrays.toString(declaredFields));
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
