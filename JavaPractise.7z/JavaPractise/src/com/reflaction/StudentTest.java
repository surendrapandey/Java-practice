package com.reflaction;

public class StudentTest {

	private String stud;

	public String getStud() {
		return stud;
	}

	public void setStud(String stud) {
		this.stud = stud;
	}
	
	
	
}
