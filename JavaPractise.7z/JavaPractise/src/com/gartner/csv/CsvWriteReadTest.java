package com.gartner.csv;
public class CsvWriteReadTest {
 
    /**
     * @param args
     */
    public static void main(String[] args) {
         
        String fileName = "C:\\projects\\KIDataFiles\\KI_CEB_Data_For_UserId.csv";
         
//        System.out.println("Write CSV file:");
//        CsvFileWriter.writeCsvFile(fileName);
         
        System.out.println("\nRead CSV file:");
        CsvFileReader.readCsvFile(fileName);
 
    }
 
}