package com.gartner.csv;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
 
/**
 * @author ashraf_sarhan
 *
 */
public class CsvFileReader {
     
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
     
    //Student attributes index
    private static final int USERNAME_IDX = 0;
    private static final int PK_User_Id_IDX = 1;
    private static final int Id_ID = 2;
    private static final int Title_IDX = 3; 
    
    private static final char DEFAULT_SEPARATOR = ',';
    private static final char DEFAULT_QUOTE = '"';
     
    public static void readCsvFile(String fileName) {
    	long start = System.currentTimeMillis();
    	
    	
    	////
    	Connection con = null;
    	Statement stmt = null;
    	
    	try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//production database
			con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@guspr-rds.pdo.aws.gartner.com:1521:guspr","GGDEVUSR","ggdv12pr"); 
			/*con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@guspv.pdoqa.aws.gartner.com:1521:guspv","ggzapusr","bkeif");*/ 
			stmt=con.createStatement();
			
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  
 ///////
 //       BufferedReader fileReader = null;
      
        try {
             
            //Create a new list of student to be filled by CSV file data 
            Set<String> kiDetailsSet = new HashSet<>();
            Map<String,String> kiDetailsMap = new HashMap<>();
            List<KIDetails> kiDetailsList = new ArrayList<>();
             
    //        String line = "";
             
          /*  //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileName));
             
            //Read the CSV file header to skip it
            fileReader.readLine();
             
            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    //Create a new student object and fill his  data
                    KIDetails kiDetail = new KIDetails(tokens[USERNAME_IDX], tokens[PK_User_Id_IDX], tokens[Id_ID], tokens[Title_IDX]);
                    kiDetailsList.add(kiDetail);
                    kiDetailsSet.add(tokens[USERNAME_IDX]);
                }
            }*/
            
            
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNext()) {
                List<String> line = parseLine(scanner.nextLine());
                KIDetails kiDetail = new KIDetails(line.get(0), line.get(1), line.get(2), line.get(3));
                kiDetailsList.add(kiDetail);
                kiDetailsSet.add(line.get(0));
            }
            scanner.close();
             
            //Print the new student list
				String query = "'surendnotvalid'";
            for (String student : kiDetailsSet) {
            	student = student.replace("'", "''");
            	query = query+",'"+student.toUpperCase()+"'";
            }
            	try {
            		System.out.println("SELECT email_txt, usr_id FROM GGAPPADM.GG_USR where upper(LOGIN_TXT) IN ("+query+")");
            		ResultSet rs=stmt.executeQuery("SELECT email_txt, usr_id FROM GGAPPADM.GG_USR where upper(LOGIN_TXT) IN ("+query+")"); 
            		while(rs.next()) {
            			kiDetailsMap.put((rs.getString(1).toLowerCase()), rs.getString(2));
            			System.out.println("UserName-"+rs.getString(1)+",UserId-"+rs.getString(2));
            		}
            	}catch(Exception e) {
            		e.printStackTrace();
            	}
            
            ////
            FileWriter writer = new FileWriter("C:\\projects\\KIDataFiles\\User_KI_CEB.csv"); //This new file need to process again. Add header in this file as -> UserName,PK_User_Id,Id,Title
			writer.write("UserName,Gartner_userId,PK_User_Id,Id,Title");	//Insert header in the file.
			writer.write("\n");
			kiDetailsList.forEach(e ->{
				try {
					writer.write(e.getUserName()+","+kiDetailsMap.get(e.getUserName().toLowerCase())+","+1+","+e.getKiId()+",\""+e.getTitle()+"\"");
					writer.write("\n");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			});
            //todo take string for writer and userid from map.
            
            /////
			writer.close();
            con.close();
        } 
        catch (Exception e) {
            System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
          //      fileReader.close();
                if(con != null) {
                	con.close();
                }
            } catch (SQLException e) {
                System.out.println("Error while closing fileReader/connection !!!");
                e.printStackTrace();
            }
        }
        System.out.println("Time taken in seconds  - "+(System.currentTimeMillis()-start)/1000);
 
    }
    
    public static List<String> parseLine(String cvsLine) {
        return parseLine(cvsLine, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
    }

    public static List<String> parseLine(String cvsLine, char separators) {
        return parseLine(cvsLine, separators, DEFAULT_QUOTE);
    }
    
    public static List<String> parseLine(String cvsLine, char separators, char customQuote) {

        List<String> result = new ArrayList<>();

        //if empty, return!
        if (cvsLine == null && cvsLine.isEmpty()) {
            return result;
        }

        if (customQuote == ' ') {
            customQuote = DEFAULT_QUOTE;
        }

        if (separators == ' ') {
            separators = DEFAULT_SEPARATOR;
        }

        StringBuffer curVal = new StringBuffer();
        boolean inQuotes = false;
        boolean startCollectChar = false;
        boolean doubleQuotesInColumn = false;

        char[] chars = cvsLine.toCharArray();

        for (char ch : chars) {

            if (inQuotes) {
                startCollectChar = true;
                if (ch == customQuote) {
                    inQuotes = false;
                    doubleQuotesInColumn = false;
                } else {

                    //Fixed : allow "" in custom quote enclosed
                    if (ch == '\"') {
                        if (!doubleQuotesInColumn) {
                            curVal.append(ch);
                            doubleQuotesInColumn = true;
                        }
                    } else {
                        curVal.append(ch);
                    }

                }
            } else {
                if (ch == customQuote) {

                    inQuotes = true;

                    //Fixed : allow "" in empty quote enclosed
                    if (chars[0] != '"' && customQuote == '\"') {
                        curVal.append('"');
                    }

                    //double quotes in column will hit this!
                    if (startCollectChar) {
                        curVal.append('"');
                    }

                } else if (ch == separators) {

                    result.add(curVal.toString());

                    curVal = new StringBuffer();
                    startCollectChar = false;

                } else if (ch == '\r') {
                    //ignore LF characters
                    continue;
                } else if (ch == '\n') {
                    //the end, break!
                    break;
                } else {
                    curVal.append(ch);
                }
            }

        }

        result.add(curVal.toString());

        return result;
    }
 
}