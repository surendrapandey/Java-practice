package com.gartner.csv;


public class KIDetails {
     
    private String userName;
    private String pkUserId;
    private String gartnerUserId;
    private String kiId;
    private String title;
    
    
    
    
	public KIDetails(String userName, String pkUserId, String kiId, String title) {
		super();
		this.userName = userName;
		this.pkUserId = pkUserId;
		this.kiId = kiId;
		this.title = title;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPkUserId() {
		return pkUserId;
	}
	public void setPkUserId(String pkUserId) {
		this.pkUserId = pkUserId;
	}
	public String getGartnerUserId() {
		return gartnerUserId;
	}
	public void setGartnerUserId(String gartnerUserId) {
		this.gartnerUserId = gartnerUserId;
	}
	public String getKiId() {
		return kiId;
	}
	public void setKiId(String kiId) {
		this.kiId = kiId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
    
    
    
}