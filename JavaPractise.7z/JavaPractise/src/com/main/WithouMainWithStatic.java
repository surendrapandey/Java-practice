package com.main;
public class WithouMainWithStatic
{
	public static void main(String[] args) {
		System.out.println(Math.abs(5));
		System.out.println(Math.abs(-5));
		System.out.println(Integer.MIN_VALUE);
	
	}
	static {
		System.out.println("hi");
	}
	
}