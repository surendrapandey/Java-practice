package com.main;

class RumClassWithouMain
{
    public static void main(String[] args)
    {
        System.out.println(1);
    }
}
 
/*public class RumClassWithouMainTest extends RumClassWithouMain
{
 
}*/
public class RumClassWithouMainTest
{
	static {
		System.out.println("hi");
	}
	
}