package com.datastructure.last;

public class LinkedListImplementationNew {

	public static void main(String[] args) {


		Node<Integer> node1 = new Node<Integer>(1);
		CustomLinkedList<Integer> list = new CustomLinkedList<Integer>();
		Node<Integer> node2 = new Node<Integer>(2);
		Node<Integer> node3 = new Node<Integer>(3);
		Node<Integer> node4 = new Node<Integer>(4);
		list.addFirst(node2);
		list.addFirst(node1);
		list.addLast(node3);
//		list.removeLast();
		list.addLast(node4);
//		list.removeFirst();*/
		list.showList();
		boolean isContain = list.contains(2);
		System.out.println(isContain);
		isContain = list.contains(5);
		System.out.println(isContain);
		list.remove(3);
		list.clear();
	}

}
class CustomLinkedList<T>{
	private Node<T> head = null;
	private Node<T> tail = null;
	private int count = 0;
	
	public void addLast(Node<T> node3) {
		if(count == 0) {
			head = node3;
		}else {
			tail.next = node3;
		}
		tail = node3;
		count++;
	}
	
	//remove all tha element from the list
	public void clear() {
		head = null;
		tail = null;
		count = 0;
	}
	public void remove(T i) {
		if(count != 0) {
			Node<T> current = head;
			if(count == 1) {
				if(current.value.equals(i)) {
					head = null;
					tail = null;
				}
			}else {
				while(current.next != null) {
					if(current.next.value.equals(i)) {
						if(current.next.equals(tail)) {
							current.next = null;
							tail = current;
							count--;
						}else {
							current.next = current.next.next;
							count--;
						}
						
					}
				}
			}
		}
		
	}
	public boolean contains(T i) {
		if(count == 1) {
			if(head.value.equals(i)) {
				return true;
			}
		}else {
			Node<T> current = head;
			while(current.next != null) {
				if(current.value.equals(i) ) {
					return true;
				}
				current = current.next;
			}
			return current.value.equals(i);
		}
		
		return false;
	}
	public void showList() {
		Node<T> node = head;
		while(node.next != null) {
			System.out.print(node.value+" , ");
			node = node.next;
		}
		System.out.println(node.value);
	}
	public void removeFirst() {
		if(count != 0) {
			if(count ==1) {
				head = null;
				tail = null;
			}else {
				head = head.next;
			}
			count--;
		}
		
		
	}
	public void removeLast() {
		if(count != 0) {
			if(count == 1) {
				head = null;
				tail = null;
			}else {
				Node<T> current = head;
				while(current.next !=tail) {
					current = current.next;
				}
				current.next = null;
				tail = current;
			}
		}
		
	}
	public void addFirst(Node<T> node) {
		Node<T> temp = head;
		head = node;
		head.next = temp;
		count++;
		if(count == 1) {
			tail = head;
		}
	}
}

class Node<T>{
	T value;
	Node<T> next;
	Node(T value){
		this.value = value;
		this.next = null;
	}
}
