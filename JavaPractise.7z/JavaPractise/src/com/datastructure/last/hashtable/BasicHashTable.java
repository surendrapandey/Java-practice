package com.datastructure.last.hashtable;

public class BasicHashTable<K,V> {

	private HashEntry[] data;
	private int capacity;
	private int size;
	
	
	public BasicHashTable(int tableSize) {
		this.capacity = tableSize;
		this.data = new HashEntry[this.capacity];
		size = 0;
	}
	
	public V get(K key) {
		int hash = calculateHash(key);
		
		if(data[hash] == null) {
			return null;
		}else {
			return (V) data[hash].getValue();
		}
	}
	
	public void put(K key, V value) {
		int hash = calculateHash(key);
		data[hash]  = new HashEntry<K,V>(key,value);
		size++;
	}
	
	public V delete(K key) {
		V v = get(key);
		if(v !=null) {
			int hash = calculateHash(key);
			data[hash] = null;
			size--;
			hash = (hash+1) % this.capacity;
			while(data[hash] !=null) {
				HashEntry<K,V> he = data[hash];
				data[hash] = null;
				put(he.getKey(),he.getValue());
				size--;
				hash = (hash+1)% this.capacity;
			}
		}
		return v;
	}
	
	public boolean hasKey(K key) {
		int hash = calculateHash(key);
		HashEntry<K, V> entry = data[hash];
		
		if(entry != null) {
			if(key.equals(entry.getKey())){
				return true;
			}
		}
		return false;
		
	}
	
	/*public boolean hasValue(V value) {
		int hash = calculateHash(key);
		if(data[hash] != null) {
			
		}
	}*/
	
	private int calculateHash(K key) {
		int hash = (key.hashCode() % this.capacity);
		while(data[hash] !=null && !data[hash].getKey().equals(key)) {
			hash = (hash+1) % this.capacity;
		}
		return hash;
	}
	
	public int size() {
		return this.size;
	}

	private class HashEntry<K,V>{
		private K key;
		private V value;
		
		public HashEntry(K k, V v) {
			this.key = k;
			this.value = v;
		}

		public K getKey() {
			return key;
		}

		public void setKey(K key) {
			this.key = key;
		}

		public V getValue() {
			return value;
		}

		public void setValue(V value) {
			this.value = value;
		}
		
		
		
	}
}
