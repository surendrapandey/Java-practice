package com.datastructure.linkedlist;

import java.util.LinkedList;
import java.util.List;

public class MergeTwoSortedLinkedListIntoSingle {

	public static void main(String[] args) {
		List<Integer> l1 = new LinkedList<>();	
		l1.add(2);
		l1.add(4);
		l1.add(6);
		l1.add(9);
		List<Integer> l2 = new LinkedList<>();	
		l2.add(1);
		l2.add(3);
		l2.add(5);
		l2.add(10);
		
		List<Integer> l3 = new LinkedList<>();
		
		l1.get(0);
		
	}

}
