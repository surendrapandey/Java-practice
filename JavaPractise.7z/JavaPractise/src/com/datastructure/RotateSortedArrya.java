package com.datastructure;

public class RotateSortedArrya {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Find in a sorted array how many times it is rotated
		int [] arr = {16,25,29,1,5,8,9};
					//0 ,1 ,2 ,3 ,4,5,6,7
		System.out.println(noOfRotattionInArrayUsingBinarySearch(arr,arr.length));
		System.out.println(noOfRotattionInCirculerArrayUsingBinarySearch(arr,arr.length));
	}


	private static int noOfRotattionInArrayUsingBinarySearch(int[] arr, int length) {

		int low = 0,high=length-1,mid=-1;
		while(low<=high) {
			mid=(low+high)/2;
			if(arr[low] <= arr[high]) {
				return low;
			}
			if((arr[mid]<=arr[mid-1]) && (arr[mid]<=arr[mid+1])) {
				return mid;
			}else if(arr[mid]<= arr[high]){
				high = mid-1;
			}else if(arr[mid] >= arr[low]){
				low = mid+1;
			}
		}
		return -1;
	}

	private static int noOfRotattionInCirculerArrayUsingBinarySearch(int[] arr, int length) {
		int low = 0, high=length-1, mid=-1,next,prev;
		while(low<=high) {
			mid=(low+high)/2;
			prev = (mid-1)%length;
			next =(mid+1)%length;
			if(arr[low] <= arr[high]) {
				return low;
			}
			if(arr[mid] <arr[next] && arr[mid] < arr[next]) {
				return mid;
			}else if(arr[mid] <=arr[high]) {
				high = mid-1;
			}else if(arr[mid] > arr[low]) {
				low = mid+1;
			}
		}
		return mid;
	}
}
