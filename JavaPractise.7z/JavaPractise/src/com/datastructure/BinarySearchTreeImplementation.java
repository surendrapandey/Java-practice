package com.datastructure;

import java.util.Stack;

public class BinarySearchTreeImplementation {
	static Node rootNode = null;

	public static void main(String[] args) {
		rootNode = insertNode(rootNode,12);
		Node node = new Node();
		node = insertNode(rootNode,5);
		node = insertNode(node,3);
		node = insertNode(node,7);
		node = insertNode(node,1);
		node = insertNode(node,9);
		node = insertNode(node,17);
		node = insertNode(node,13);
		
/*		System.out.println(binarySearch(rootNode,9));
		System.out.println(binarySearch(rootNode, 25));
		System.out.println("---------In Order-------");
		inOrderTraversal(rootNode);*/
//		System.out.println("---------Pre Order-------");
//		preOrderTraversal(rootNode);
//		System.out.println("---------:Post Order-------");
//		postOrderTraversal(rootNode);

		/*System.out.println(findMin(rootNode));
		System.out.println(findMax(rootNode));*/
//		System.out.println(findMinWithoutRecursion(rootNode));
//		System.out.println(findMaxWithoutRecursion(rootNode));

		inOrderWithoutRecursion();
		delete(rootNode, 5);
		System.out.println("-------------j");
		inOrderWithoutRecursion();
		
		
	}
	
	private static Node delete(Node root, int data) {
		if(root == null) {
			return root;
		}else if(data < root.data) {
			 delete(root.left, data);
		}else if(data > root.data){
			delete(root.right, data);
		}else {
			if(root.left == null && root.right == null) {
				root = null;
			}else if(root.left == null){
				Node curr = root;
				root = root.right;
				curr = null;
			}else if(root.right == null) {
				Node curr = root;
				root = root.left;
				curr = null;
			}else {
				Node temp = findMinNode(root.right);
				root.data = temp.data;
				root.right = delete(root.right, temp.data);
			}
		}
		return root;
		
	}

	private Node findLeftMostNode(Node root) {
		Node n = new Node();
		while(n.left != null) {
			n = n.left;
		}
		return n;
	}
	
	private Node findRightMostNode() {
		Node n = new Node();
		while(n.right != null) {
			n = n.right;
		}
		return n;
	}

	private static Node insertNode(Node root, int i) {
		if(root == null) {
			root = getNode(i);
		}
		else if(i<= root.data) {
			root.left = insertNode(root.left,i);
		}else {
			root.right = insertNode(root.right,i);
		}
		return root;
	}
	
	private static boolean search(Node root, int data) {
		if(root == null) {
			return false;
		}
		if(data ==root.data) {
			return true;
		}else if(data <= root.data) {
			return search(root.left,data);
		}else {
			return search(root.right, data);
		}
	}
	
	private static int findMin(Node root) {
		if(root.left != null) {
			return findMin(root.left);
		}
		return root.data;
	}
	
	private static Node findMinNode(Node root) {
		if(root.left != null) {
			return findMinNode(root.left);
		}
		return root;
	}
	
	private static int findMinWithoutRecursion(Node root) {
		
		while(root.left !=null) {
			root = root.left;
		}
		return root.data;
	}
	
	private static int findMax(Node root) {
		if(root.right != null) {
			return findMax(root.right);
		}
		return root.data;
	}
	private static int findMaxWithoutRecursion(Node root) {
		while(root.right != null) {
			root = root.right;
		}
		return root.data;
	}
	
	public static void inOrderWithoutRecursion() {
		Stack<Node> stack = new Stack<>();
		Node currentNode = rootNode;
		while(!stack.empty() || currentNode != null) {
			if(currentNode !=null) {
				stack.push(currentNode);
				currentNode = currentNode.left;
			}else {
				Node node = stack.pop();
				System.out.println(node.data);
				currentNode = node.right;
			}
		}
	}
	private static void inOrderTraversal(Node root) {
		if(root == null) {
			return;
		}
		
		inOrderTraversal(root.left);
		System.out.println(root.data);
		inOrderTraversal(root.right);
	}
	private static void preOrderTraversal(Node root) {
		if(root == null) {
			return;
		}
		
		System.out.println(root.data);
		inOrderTraversal(root.left);
		inOrderTraversal(root.right);
	}
	private static void postOrderTraversal(Node root) {
		if(root == null) {
			return;
		}
		
		inOrderTraversal(root.left);
		inOrderTraversal(root.right);
		System.out.println(root.data);
	}

	private static Node getNode(int i ){
		Node node = new Node();
		node.data = i;
		node.left = null;
		node.right = null;
		return node;
	}
}

class Node{
	Node left;
	Node right;
	int data;
}
