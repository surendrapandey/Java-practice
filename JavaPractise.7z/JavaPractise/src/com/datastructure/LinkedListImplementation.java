package com.datastructure;

public class LinkedListImplementation {

	public static void main(String[] args) {
		LinkedList l = new LinkedList();
		l.add(3);
		l.add(4);
		l.add(5);
		l.showList();
		l.reverseList();
		l.showList();
	}

}


class LinkedList{
	Node head ;
	
	public void add(int i ) {
		Node n = new Node();
		n.data = i;
		n.next = null;
		
		if(head == null) {
			head = n;
			return;
		}
	//	head.next = n;
		
		Node n1 = head;
		while(n1.next !=null) {
			n1 = n1.next;
		}
		n1.next = n;
	}
	
	public void removeAt(int i ) {
		if(head == null) {
			System.out.println("list is empty");
			return;
		}
		Node n1 = head;
		for(int j=0; j<i ;j++) {
			n1 = n1.next;
		}
		Node temp = n1;
		n1 = n1.next;
		System.out.println("removing - "+n1.data);
		temp.next = n1.next;
	}
	
	public void reverseList() {
		if(head == null) {
			System.out.println("list is blank");
			return;
		}
		
		Node pre = null;
		Node curr = head;
		Node next = null;
		
		while(curr != null) {
			next = curr.next;
			curr.next = pre;
			pre = curr;
			curr = next;
		}
		head = pre;
	}
	
	public void showList() {
		Node n = head;
		while(n.next != null) {
			System.out.println(n.data);
			n = n.next;
		}
		System.out.println(n.data);
		
		
	}
	

private class Node{
	int data;
	Node next;
	
}
}
