package com.datastructure;

public class BinarySearchAlgoImplementation {
	static int mid = 0;

	public static void main(String[] args) {
			
		//It require sorted array/
		int[] arr = new int[12];
		
		arr[0] = 4;
		arr[1] = 12;
		arr[2] = 16;
		arr[3] = 19;
		arr[4] = 21;
		arr[5] = 25;
		arr[6] = 28;
		arr[7] = 31;
		arr[8] = 36;
		arr[9] = 39;
		arr[10] = 42;
		arr[11] = 44;
		
		binarySearch(arr,12);
	}
	
	
	private static void binarySearch(int [] arr, int n) {
		
		int start=0,end=arr.length-1,mid;
		while(start <= end) {
			mid = (start+end)/2;
			if(n == arr[mid]) {
				System.out.println("found");
				return;
			}else if(n < arr[mid]) {
				end = mid-1;
			}else {
				start = mid+1;
			}
		}
		System.out.println("not found");
		return;
	}
}
