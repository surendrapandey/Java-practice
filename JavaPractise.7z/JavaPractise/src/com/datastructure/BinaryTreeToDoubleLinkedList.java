package com.datastructure;

public class BinaryTreeToDoubleLinkedList {

	TreeNode root ;
	TreeNode head;
	static TreeNode prev = null;
	public static void main(String[] args) {
		BinaryTreeToDoubleLinkedList tree = new BinaryTreeToDoubleLinkedList();
		tree.root = new TreeNode(10); 
        tree.root.left = new TreeNode(12); 
        tree.root.right = new TreeNode(15); 
        tree.root.left.left = new TreeNode(25); 
        tree.root.left.right = new TreeNode(30); 
        tree.root.right.left = new TreeNode(36);
        
        tree.convertToDLL(tree.root); 
        
        tree.printList(tree.head); 
	}
	
	void convertToDLL(TreeNode root) {
		if(root == null) {
			return ;
		}
		convertToDLL(root.left);
		if(prev == null) {
			head = root;
		}else {
			root.left = prev;
			prev.right = root;
		}
		prev = root;
		convertToDLL(root.right);
		
	}
	void printList(TreeNode node) 
    { 
        while (node != null)  
        { 
            System.out.print(node.val + " "); 
            node = node.right; 
        } 
    }

}

class TreeNode{
	public int val;
	public TreeNode left;
	public TreeNode right;
	
	public TreeNode(int val, TreeNode left, TreeNode right) {
		super();
		this.val = val;
		this.left = left;
		this.right = right;
	}

	public TreeNode(int i) {
		this.val = i;
		left = null;
		right = null;
	}
	
	
}
