package com.datastructure;

public class QueueImplementation {

	public static void main(String[] args) throws Exception {
		Queue q = new Queue();
//		q.deQueue();
		q.enQueue(4);
		q.enQueue(5);
		q.enQueue(6);
		System.out.println(q.deQueue());
		System.out.println(q.deQueue());
		System.out.println(q.deQueue());
		System.out.println(q.deQueue());
		System.out.println(q.deQueue());
		q.enQueue(7);
		q.enQueue(8);
		q.enQueue(9);
		System.out.println(q.deQueue());
		System.out.println(q.deQueue());
	}
	
	
}

class Queue{
	int [] arr = new int[5];
	int  front;
	int rear;
	
	Queue(){
		this.front= this.rear = -1;
	}
	
	public void enQueue(int i ) throws Exception {
		if(isFull()) {
			throw new Exception("Queue is full");
		}else if(isEmpty()) {
			front = rear = 0;
		}else {
			rear = rear+1;
		}
		arr[rear] = i;
	}
	
	public int deQueue() throws Exception {
		if(isEmpty()) {
			throw new Exception("Queue is empty");
		}else if(front == rear ) {
			front = rear = -1;
		}else {
			front = front+1;
		}
		return arr[front];
	}

	private boolean isEmpty() {
		if(front == -1 && rear == -1)
		return true;
		return false;
	}

	private boolean isFull() {
		if(rear == arr.length-1)
		return true;
		return false;
		
	}
}
