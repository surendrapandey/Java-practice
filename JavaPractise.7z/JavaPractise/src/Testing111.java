import java.util.Scanner;

public class Testing111 {

	public static void main(String[] args) {
		// TODO code application logic here
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of friends john have");
		int n = sc.nextInt();
		String str[] = new String[n];
		System.out.println("Enter the friends name of john");
		for (int i = 0; i < n; i++) {
			str[i] = sc.next();
		}
		String s[] = new String[25];
		String str1[] = new String[25];
		int j = 0;
		int e[] = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.println("Enter the number of friends for " + str[i]);
			e[i] = sc.nextInt();
			System.out.println("Enter the friends name of " + str[i]);
			for (; j < e[i]; j++) {
				str1[j] = sc.next();
			}
		}
		int f = 0, o = 0;
		for (int i = 0; i < 25; i++) {
			for (int k = i + 1; k < 25; k++) {
				if (str1[i].equals(str1[k])) {
					o++;
				} else {
					s[f] = str[i];
					f++;
				}
			}
		}
		System.out.println("The new friends of john are");
		for (int i = 0; i < f; i++) {
			System.out.print(s[i] + " ");
		}
		System.out.println("They have " + o + " friends in common");
	}
}
