
public class Alpha 
{ 
    public static void main(String[] args)
    { 

    	System.out.println(get());
    } 
    @SuppressWarnings("finally")
	public static int get() {
    	try {
    		int x = 0;
    		if(x==0) {
    			throw new Exception();
    		}
    		return 1;
    	}catch(Exception e) {
    		return 2;
    	}
    }
}

