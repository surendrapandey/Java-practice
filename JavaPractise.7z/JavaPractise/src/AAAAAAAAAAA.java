import java.util.Set;

public class AAAAAAAAAAA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Long> set = null;
		set.forEach(e -> System.out.println(e));

	}

}
