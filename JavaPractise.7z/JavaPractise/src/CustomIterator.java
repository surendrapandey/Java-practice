import java.util.Iterator;

public class CustomIterator<Type> implements Iterable<Type>{
	
	private Type[] arrayList ;
	private int size;
	
	public CustomIterator() {
	}
	
	void CustomIterator(){
		
	}
	
	

	@Override
	public Iterator<Type> iterator() {
		Iterator<Type> it = new Iterator<Type>() {

			@Override
			public boolean hasNext() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public Type next() {
				// TODO Auto-generated method stub
				return null;
			}
			
		};
		return null;
	}
	
}
