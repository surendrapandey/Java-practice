package test.test1;

import test.test2.Test2;

public class Test1 {
	static int x = 10;
	static Integer y ;
	public static void main(String[] args) {
		Test2 a = new Test2();
		//below line give compile time error becuause x scope is default(x will be visible in same package onle)
//		System.out.println(a.x);
		System.out.println(a.y);
		y = new Integer(5);
		
		Tempt t = new Tempt2();
		System.out.println(t.print());
		System.out.println(Tempt.print());
	}
	
	

}

class Tempt{
	static String print() {
		return "parent static";
	}
}

class Tempt2 extends Tempt{
	static String print() {
		return "child static";
	}
}
