package test.test2;

public class Test2 {

	int x=10;
	public int y=20;
}
