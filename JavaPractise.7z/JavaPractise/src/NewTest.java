import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class NewTest {

	public static void main(String[] args) {

		Map<String, Integer> kiMap = new HashMap<>();
		kiMap.put("aa", 16643);
		kiMap.put("bb", 16644);
		kiMap.put("cc", 16645);
//		System.out.println(kiMap.get("aa"));
//		System.out.println(kiMap);
	}
	
	static String twoStrings(String s1, String s2) {
	       // if(s1.length()>s2.length()){
	            char[] s2Array = s2.toCharArray();
	            char[] s1Array = s1.toCharArray();
	            Map<Character, Integer> map = new HashMap<>();
	            for(int i = 0 ; i< s1Array.length; i++){
	                if(map.containsKey(s1Array[i])){
	                    map.put(s1Array[i],map.get(s1Array[i])+1);
	                }else{
	                    map.put(s1Array[i],1);
	                }
	            }
	            for(int i = 0; i< s2Array.length; i++){
	                if(map.conatinsKey(s2Array[i])){
	                    return "Yes";
	                }
	            }
	      //  }
	        return "No";

	    }

}
