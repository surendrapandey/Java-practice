
public interface I{

}
