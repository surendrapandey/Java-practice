

@FunctionalInterface
public interface TestInterface {
	public int m();
}
