import java.util.Arrays;

public class Test2 {

	public static void main(String[] args) {
		int arr[] = {0,1,3,2};
		System.out.println(minimumSwaps(arr));
		
	}
	 static int minimumSwaps(int[] arr) {
	        int temp = 0;
	        int[] arr2 = new int[arr.length];
	        for(int i = 0; i<arr.length; i++) {
	        	arr2[i] = arr[i];
	        }
	        Arrays.sort(arr2);
	        int count = 0;
	        int index1 = 0;
	        int index2 = 0;
	        for(int i = 0; i< arr.length; i++){
	            if(arr[i] != arr2[i]){
	                index1 = i;
	                for(int j = i+1; j<arr.length;j++){
	                    if(arr2[i]== arr[j]){
	                        index2 = j;
	                        break;
	                    }
	                }
	                temp = arr[index1];
	                arr[index1] = arr[index2];
	                arr[index2] = temp;
	                count++; 
	            }
	        }
	        
	    return count;
	    }

}
