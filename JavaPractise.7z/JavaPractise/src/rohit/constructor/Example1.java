package example.constructor;

public class Example1 {

	public static void main(String[] args) {
		

	}

}

/*class Creature{
	private int legCount;
	//protected int wingCount;
	private int wingCount;
	
	public Creature(int legCount) {
		this.legCount = this.legCount;
		this.wingCount = 0;
	}
}

class Animal extends Creature{
	public Animal(int legcount) {
		//super(legcount);
		this.wingCount = 0;
	}
}*/