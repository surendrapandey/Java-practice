package example.constructor;

public class Example2 {

	public static void main(String[] args) {

	}

}

/*class A {
	
	public A(int i) {

	}
}

class B extends A {
	public B(int i) {
	}

}*/