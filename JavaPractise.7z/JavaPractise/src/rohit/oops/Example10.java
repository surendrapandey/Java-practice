package example.oops;

class XYZ {
	final int fi = 10;
}

public class Example10 extends XYZ {
	int fi = 15;

	public static void main(String[] args) {
		Example10 b = new Example10();
		b.fi = 20;
		System.out.println(b.fi);
		System.out.println(((XYZ) b).fi);
	}
}