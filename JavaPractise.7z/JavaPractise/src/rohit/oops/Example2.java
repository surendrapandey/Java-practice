package rohit.oops;


class Super1 {
	public String toString() {
		return "4";
	}
}

public class Example2 extends Super1 {
	public String toString() {
		return super.toString() + "3";
	}

	public static void main(String[] args) {
		System.out.println(new Example2());
	}
}