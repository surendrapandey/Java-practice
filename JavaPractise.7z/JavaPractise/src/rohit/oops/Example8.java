package example.oops;

public class Example8 {
	public static void main(String[] args) {
		AA a = new AA();
		BB b = new BB();

		/*a = (BB) (II) b;
		b = (BB) (II) a; //Runtime Error
		a = (II) b;
		II i = (CC) a; //Runtime Error
*/	}
}

interface II {
}

class AA implements II {
}

class BB extends AA {
}

class CC extends BB {
}
