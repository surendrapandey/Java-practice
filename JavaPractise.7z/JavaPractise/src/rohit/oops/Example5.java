package rohit.oops;

class Super {
	public void print(){
		System.out.println("super");
	}
}

class Sub extends Super {
	public void print() {
		System.out.println("Child");
	}
}

public class Example5 {
	public static void main(String[] args) {
		Super s1 = new Super(); // 1
		Sub s2 = new Sub(); // 2
		Super s3 = (Super) s2; // 3
		Super s4 = new Sub();
		//Sub s5 = (Sub)s1;
		s1.print();
		s3.print();
		s4.print();
		
	}
}
