package rohit.oops;

interface Bozo{
    int type = 0;
    public void jump();
}

public class Example12 implements Bozo{
  /*  public Example12(){
		type = 1;
    }*/
public void jump(){
       System.out.println("jumping..."+type);
    }
     public static void main(String[] args){
       Bozo b = new Example12();
       b.jump();
    }
}

/*
 * Explanation: 
 * Fields defined in an interface are ALWAYS considered as public,
 * static, and final. (Methods are public and abstract.) Even if you don't
 * explicitly define them as such. In fact, you cannot even declare a field to
 * be private or protected in an interface. Therefore, you cannot assign any
 * value to 'type' outside the interface definition.
 */
