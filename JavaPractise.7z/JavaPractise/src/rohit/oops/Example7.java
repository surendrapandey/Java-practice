package rohit.oops;

public class Example7 {
	public static void main(String[] args) {
	}
}

class A2 {
	public void m1(String a) {

	}

	public void m2(String a) {

	}
}

class B2 extends A2 {
	//compile time error because method with argument/s , cannot have diff return type
	/*public String m1(String a) {
		return null;
	}*/

	//not override
	public void m2() {

	}
	
	//not override
	public String m2(int a) {
		return null;
	}

}