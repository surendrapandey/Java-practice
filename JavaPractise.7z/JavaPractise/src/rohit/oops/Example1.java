package example.oops;

public class Example1 {

	public static void main(String[] args) {
		  A a = new A();
		  B b = new B();
		  C c = new C();
		  /*b = c ;
		  MyIface i = c;
		  c = (C)b;
		  b = a;
		  b = (B)a;*/
	}

}

interface MyIface {
}

class A {
}

class B extends A implements MyIface {
}

class C implements MyIface {
}