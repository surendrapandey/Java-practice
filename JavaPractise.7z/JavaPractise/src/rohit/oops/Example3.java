package rohit.oops;

public class Example3 {

	public static void main(String[] args) {
		Vehicle v = new Car();
		Bike b = (Bike) v;
		v.printSound();
		b.printSound();

	}

}

class Vehicle {
	public void printSound(){
		System.out.println("vehicle");
	}
}
class Car extends Vehicle {
	public void printSound(){
		System.out.println("car");
	}
}
class Bike extends Vehicle {
	public void printSound(){
		System.out.println("bike");
	}
}