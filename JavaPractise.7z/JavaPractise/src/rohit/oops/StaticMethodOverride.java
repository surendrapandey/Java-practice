package rohit.oops;

public class StaticMethodOverride {

	public static void main(String[] args) {
		A1.sM1();
		B1.sM1();
		A1 a = new B1();
		a.sM1(); // we can override static methods but run-time polymorphism can't be achieved. 
				 // Hence we can't override static methods
	}
}

class A1 {
	public static void sM1() {
		System.out.println("In base static");
	}
}

class B1 extends A1 {
	public static void sM1() {
		System.out.println("In sub static");
	}
	// public void sM1() { System.out.println("In sub non-static"); }
}
