package example.oops;

import java.io.*;

class Great1 {
	public void doStuff() throws IllegalArgumentException {
	}
}

class Amazing1 extends Great1 {
	public void doStuff() throws RuntimeException {
	}
}

public class OverrideWithRuntimeException {
	public static void main(String[] args) throws IOException {
		Great1 g = new Amazing1();
		g.doStuff();
	}

}
//No need to worry about Unchecked exception.


/*Exception
	|
	|-	RuntimeException
			|
			|- IllegalArgumentException*/