package example.oops;

public class Example4 {
	/*String s; 
	String s1 = 'asdf'; 
	String s2 = 'a'; 
	String s3 = this.toString(); 
	char c = "d";*/
	
	//uncomment
}
