package example.oops;

public class Example6 implements T1, T2 {
	public static void main(String[] args) {
		Example6 e = new Example6();
		e.m1();
		//e.VALUE;
	}
	public void m1() {
	}
}

interface T1 {
	int VALUE = 1;
	void m1();
}

interface T2 {
	int VALUE = 2;
	void m1();
}
