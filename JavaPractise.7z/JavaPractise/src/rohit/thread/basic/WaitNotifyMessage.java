package concept.thread.basic;
public class WaitNotifyMessage {
    private String msg;
     
    public WaitNotifyMessage(String str){
        this.msg=str;
    }
 
    public String getMsg() {
        return msg;
    }
 
    public void setMsg(String str) {
        this.msg=str;
    }
 
}