package rohit.thread.basic;

public class Demo1 {

	public static void main(String[] args) {
		Time t = new Time();
		System.out.println(t);
		
	}

}

class Time {
	
}
