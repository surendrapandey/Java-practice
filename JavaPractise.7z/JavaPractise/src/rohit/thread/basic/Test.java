package concept.thread.basic;

public class Test {

	public static void main(String[] args) throws InterruptedException {
		
		Thread t = new Thread(new Abc());
		t.start();
		Thread.sleep(2000);
		System.out.println("I am done");
	}

}

class Abc implements Runnable {

	@Override
	public void run() {
		throw new NullPointerException();

	}
}
