package rohit.thread.basic;

public class ThreadByImplement implements Runnable {
	
	public static void main(String[] args) {
		
		ThreadByImplement c = new ThreadByImplement();
		Thread t = new Thread(c);
//		Thread t = new Thread(c, "myThread");
		t.start();
		
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread());
		System.out.println(Thread.currentThread().getName());
		System.out.println("hi");
	}
}