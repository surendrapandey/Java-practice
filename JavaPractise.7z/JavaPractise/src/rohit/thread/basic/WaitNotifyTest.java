package rohit.thread.basic;

public class WaitNotifyTest {

	public static void main(String[] args) {
		WaitNotifyMessage msg = new WaitNotifyMessage("process it");
		WaitNotifyWaiter waiter = new WaitNotifyWaiter(msg);
		new Thread(waiter, "Sumit").start();

		WaitNotifyWaiter waiter1 = new WaitNotifyWaiter(msg);
		new Thread(waiter1, "Sudhir").start();

		WaitNotifyNotifier notifier = new WaitNotifyNotifier(msg);
		new Thread(notifier, "Rohit").start();
		System.out.println("All the threads are started");
	}

}