package rohit.thread.basic;

public class ThreadByExtend extends Thread {
	private String threadName;

	ThreadByExtend(String name) {
		threadName = name;
		System.out.println("Creating " + threadName);
	}

	public void run() {
		System.out.println("Running " + threadName);
		try {
			for (int i = 1; i > 0; i--) {
				System.out.println("Thread: " + threadName + ", " + i);
				//Thread.sleep(50);
			}
		} catch (Exception e) {
			System.out.println("Thread " + threadName + " interrupted.");
		}
		System.out.println("Thread " + threadName + " exiting.");
	}

	public static void main(String args[]) {

		ThreadByExtend t1 = new ThreadByExtend("Thread-1");
		t1.start();
		ThreadByExtend t2 = new ThreadByExtend("Thread-2");
		t2.start();
		System.out.println(t1.isAlive());
		while (t1.isAlive()) {
			System.out.print("hi");
		}
		System.out.println(t1.isAlive());
	}

}