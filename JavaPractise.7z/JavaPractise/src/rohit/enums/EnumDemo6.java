package concept.enums;

public enum EnumDemo6 {
	STAR, GUPPY, GOLD;
	public static void main(String[] args) {
		System.out.println("enum main");
	}

}

// Specialty of enum is we can declare methods, constructors and variables in enum class.