package rohit.enums;

public class EnumDemo2 {

	public static void main(String[] args) {
		/*enum R{
			
		}*/ // we can not declare enum inside method
	}

}

enum Y{
	
}
class X{
	
}

class Z{
	enum Z1{
		
	}
}