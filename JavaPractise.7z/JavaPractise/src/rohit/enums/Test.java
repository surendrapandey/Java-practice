package rohit.enums;

import java.util.Map;
import java.util.TreeMap;

public class Test {

	public static void main(String[] args) {
		Map<Enummm,String> map = new TreeMap<>();
		map.put(Enummm.AMAN, "");
		map.put(Enummm.ROHIT, "");
		map.put(Enummm.ZYAN, "");
		
		System.out.println(map);
	}

}

enum Enummm{
	ROHIT, AMAN, ZYAN;
}