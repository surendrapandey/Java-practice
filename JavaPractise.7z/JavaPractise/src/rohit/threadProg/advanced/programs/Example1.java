package rohit.threadProg.advanced.programs;

import java.util.concurrent.CountDownLatch;

public class Example1 {

	public static void main(String[] args) throws InterruptedException {
		CountDownLatch startSignal = new CountDownLatch(1);
		startSignal.await();
		System.out.println("start");
		new Thread(new Worker(startSignal)).start();
		startSignal.countDown();
		System.out.println("End");
	}

}
// 1. startSignal.await(); throws compile time exception

class Worker implements Runnable{

	private final CountDownLatch startSignal;
	
	Worker(CountDownLatch startSignal){
		this.startSignal = startSignal;
	}
	public void run() {
		startSignal.countDown();
	}
}