package example.thread.advanced.programs;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Example2 {

	public static void main(String[] args) {
		Lock lock = new ReentrantLock();
		try{
			System.out.println("Lock 1");
			lock.lock();
			System.out.println("Critical section 1");
			System.out.println("lock 2");
			lock.lock();
			System.out.println("Critical section 2");
		}finally{
			lock.unlock();
			System.out.println("unlock 2");
			lock.unlock();
			System.out.println("unlock 1");
		}

	}

}
