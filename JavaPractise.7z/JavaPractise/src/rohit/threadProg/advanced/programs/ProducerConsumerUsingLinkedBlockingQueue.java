package rohit.threadProg.advanced.programs;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class ProducerConsumerUsingLinkedBlockingQueue {

	public static void main(String[] args) {
		BlockingQueue<String> shareResource = new LinkedBlockingDeque<>();
		
	}

}


class Producer implements Runnable{

	BlockingQueue<Object> bq;
	
	public Producer(BlockingQueue bq) {
		this.bq= bq;
	}
	
	
	@Override
	public void run() {
		while(true) {
			try {
				bq.put(new Object());
				bq.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
