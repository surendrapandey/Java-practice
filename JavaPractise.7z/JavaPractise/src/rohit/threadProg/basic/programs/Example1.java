package example.thread.basic.programs;

public class Example1 {

	public static void main(String[] args) {
		new Example1().doit();

	}

	private void doit() {
		while(true){
			try {
				wait(1000);
				break;
			} catch (InterruptedException e) {
				System.out.println("InterruptedException");
			}/* catch (Exception e) {
				System.out.println("Exception");
			}*/
		}
		System.out.println("outside while");
	}

}
