package rohit.threadProg.basic.programs;

public class Example2 extends Thread{

	public static void main(String[] args) {
		new Example2().start();
	}
	
	@Override
	public void run() {
		try{
			System.out.println("Starting to wait");
			/*synchronized (this) {				
				wait(4000);
			}*/
			wait(4000);
			System.out.println("Done waiting, returning back");
		}catch(InterruptedException e){
			System.out.println("caught InterruptedException");
		}catch(Exception e){
			System.out.println("caught Exception");
		}
	}

}
