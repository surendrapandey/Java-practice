package rohit.exceptionHandle;

public class Test {

	public static void main(String[] args){
	}


}

class AAA{
	AAA(Object o){
		System.out.println("object");
	}
	AAA(String o){
		System.out.println("string");
	}
	AAA(Integer o){
		System.out.println("Integer");
	}
}
