package rohit.exception.programs;

public class ReturnFromCatchAndFinally {

	public static void main(String[] args) {

		int m = checkReturnFromTryAndFinally();
		System.out.println(m);
//		int n = checkReturnFromTryAndCatch();
//		System.out.println(n);
	}

	private static int checkReturnFromTryAndCatch() {
		try {
			int i = 1/0;
		}catch(ArithmeticException e) {
			System.out.println("inside arithmatic exception block");
		}finally {
			System.out.println("inside finally");
		}
		System.out.println("after finally");
		return 9;
	}

	private static int checkReturnFromTryAndFinally() {
		try {
			boolean flag = true;
			if(flag) {
				throw new ArithmeticException();
			}
		}catch(ArithmeticException e){
			System.out.println("B");
			//return 6;
		}finally {
			System.out.println("C");
		}
		System.out.println("D");
		return 5;
	}

}
