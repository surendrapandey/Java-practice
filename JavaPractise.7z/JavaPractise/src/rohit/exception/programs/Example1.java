package rohit.exception.programs;

public class Example1 {

	public static void main(String[] args) throws Exception {
		try {
			m1();
		} catch (Exception e) {
			m2();
		} finally {
			m3();
		}

	}

	private static void m1() throws MyException1 {
		throw new MyException1();
	}

	private static void m2() throws MyException2 {
		throw new MyException2();
	}

	private static void m3() throws MyException3 {
		throw new MyException3();
	}
}

class MyException1 extends Exception {
}

class MyException2 extends Exception {
}

class MyException3 extends Exception {
}