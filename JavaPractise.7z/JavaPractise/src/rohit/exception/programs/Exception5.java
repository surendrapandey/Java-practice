package example.exception.programs;

public class Exception5 {
	public static void methodX() throws Exception {
		throw new AssertionError();
	}

	public static void main(String[] args) {
		try {
			methodX();
		} catch (Exception e) {
			System.out.println("EXCEPTION");
		}
	}
}
// A subclass of Error cannot be caught using a catch block for Exception
// because java.lang.Error does not extend java.lang.Exception.
