package rohit.exception.programs;

public class Example2 {

	public static void main(String[] args) {
		try{
			A a = new A();
			a.doA();
		}catch(Exception e){
			System.out.println("error");
		}
	}

}
class A {
	public void doA(){
		B b = new B();
		b.doB();
		System.out.println("do A");
	}
}

class B {
	public void doB(){
		C c = new C();
		c.doC();
		System.out.println("do B");
	}
}
class C {
	public void doC(){
		if(true){
			throw new NullPointerException();
		}
		System.out.println("do C");
	}
}
