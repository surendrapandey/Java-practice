package rohit.exception.programs;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Example3 {

	public static void main(String[] args) {
		try {
			thrower();
		} catch (Throwable e) {
			System.out.println("throwable" + e.getClass());
		}

	}

	@SuppressWarnings("finally")
	private static void thrower() throws Exception {
		try{
			throw new IOException();
		}finally{
			System.out.println("finally");
			throw new FileNotFoundException();
		}
		
	}

}
