import java.io.FileNotFoundException;
import java.io.IOException;

public class Test1 {

	public static void main(String[] args) {
		//m1(5);
		Test1 t  = new Test1();
		/*t.method(null);
		t.m1(3);
		t.m1(3,3);*/
		A a = new B();
		B b =(B) new A();
	//	a.m1(3);
		System.out.println(a.i);
	}

	/*private  float  m1(int i) {
		return i;
		
	}
	private  double m1(int i) {
		return i;
		
	}*/
	private  void  m1(int  i, String [] s) {

		System.out.println(2);
	}
	/*private  void  m1(int [] i) {
		
		System.out.println(2);
	}*/
	private  void m1(Integer i) {

		System.out.println(3);
	}
	
	public void method(Object o ) {
		System.out.println("o");
	}
	public void method(String s) {
		System.out.println("s");
		
	}
	public void method(Integer i) {
		System.out.println("i");
		
	}

}


class A{
	public int i =10;
	protected   Number  m1(int i) throws IOException {
		System.out.println("super");
		return i;
	}
}

class B extends A{
	public int i =20;
	
	@Override
	public  Integer  m1(int i) throws FileNotFoundException  {
		System.out.println("child");
		return i;
	}
	private  float  m2(int i) {
		System.out.println("in m2");
		return i;
	}
}