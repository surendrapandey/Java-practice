
public class Testting111 {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(7);
		ListNode l2 = new ListNode(3);
		l2.next = new ListNode(9);
		l2.next.next = new ListNode(9);
		l2.next.next.next = new ListNode(9);
		l2.next.next.next.next = new ListNode(9);
		l2.next.next.next.next.next = new ListNode(9);
		l2.next.next.next.next.next.next = new ListNode(9);
		l2.next.next.next.next.next.next.next = new ListNode(9);
		l2.next.next.next.next.next.next.next.next = new ListNode(9);
		l2.next.next.next.next.next.next.next.next.next = new ListNode(9);
		addTwoNumbers(l1,l2);
		
	}

	/**
	 * Definition for singly-linked list. public class ListNode { int val; ListNode
	 * next; ListNode(int x) { val = x; } }
	 */
	public static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
		return null;
	}

	private static long reverseNum(long num) {// 243
		if (num < 10) {
			return num;
		}
		int mod = 0;
		long result = 0l;
		while (num >= 10) {
			mod = (int)(num % 10); // mod = 3,4
			result = result * 10 + mod; // result =3,34
			num = num / 10; // num = 24,2
		}
		return result * 10 + num; // 342
	}
}

class ListNode { 
	int val; 
	ListNode next; 
	ListNode(int x) {
		val = x; 
		} 
	}